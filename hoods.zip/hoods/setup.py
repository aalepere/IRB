import setuptools

with open("hoods/docs/README.md", "r") as fh:
    long_description = fh.read()

setuptools.setup(
    name="hoods",
    version="1.0.7",
    author="Arnaud Alepee",
    author_email="arnaud@hokodo.co",
    description="Package containing the classes used to prepare and transform data for the Credit Model",
    long_description=long_description,
    long_description_content_type="text/markdown",
    packages=[i for i in setuptools.find_packages() if 'test' not in i],
    classifiers=[
        "Programming Language :: Python :: 3",
        "Operating System :: OS Independent",
    ],
    package_data={'':['*.R', '*.ipynb']},
    include_package_data=True
)
