"""
HOODS : Generate SFA Notebook
"""

####################################
# Libraries and Runtime Parameters #
####################################
import warnings
import pandas as pd
from . import hoods_settings
from .Tools import Timer, SingleFeatureAnalysis, research_utils
warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=FutureWarning)
company_size, output_flag, for_prod_dir = hoods_settings.get_runtime_params()

############
# Analysis #
############
logger = research_utils.get_logger(company_size)
timer = Timer.Timer(logger=logger)

def run():
    ''' run generate_sfa_notebook '''
    timer.initiate_timer('Generate sfa notebook')
    dataset = pd.read_csv(hoods_settings.FEATURES_TO_REMOVE, index_col=None)
    singFeatAnalysis = SingleFeatureAnalysis.SingleFeatureAnalysis(data=dataset, output_flag=output_flag, company_size=company_size, for_prod_dir=for_prod_dir, logger=logger)
    singFeatAnalysis.create_notebook()
    timer.finish_timer('Generate sfa notebook', 'Finished generating single feature analysis notebook')
