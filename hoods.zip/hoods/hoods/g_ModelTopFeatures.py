"""
HOODS Step 8: Transform Test Set for the model
"""

####################################
# Libraries and Runtime Parameters #
####################################
import warnings
import os
from . import hoods_settings
from .Tools import PreModelAnalysis, Timer, research_utils
warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=FutureWarning)
company_size, output_flag, for_prod_dir = hoods_settings.get_runtime_params()

############
# Analysis #
############
logger = research_utils.get_logger(company_size)
timer = Timer.Timer(logger=logger)

def run():
    ''' run modeltopfeatures '''
    timer.initiate_timer('Pre Model Analysis')
    logger.info(f"PreModel : Writing 8_Train_data.csv and 8_Test_data.csv to {os.getcwd()}/data_sandbox")

    preModelTrain = PreModelAnalysis.PreModelAnalysis(data_path=hoods_settings.PRE_MODEL_TRAIN_SET, data_path_out=hoods_settings.INITIATE_MODEL_TRAIN_SET, logger=logger, output_flag=output_flag, for_prod_dir=for_prod_dir)
    preModelTrain.remove_features_and_write_data()

    preModelTest = PreModelAnalysis.PreModelAnalysis(data_path=hoods_settings.PRE_MODEL_TEST_SET, data_path_out=hoods_settings.INITIATE_MODEL_TEST_SET, logger=logger, output_flag=output_flag, for_prod_dir=for_prod_dir)
    preModelTest.remove_features_and_write_data()
    timer.finish_timer('Pre Model Analysis', 'Pre Model analysis')
