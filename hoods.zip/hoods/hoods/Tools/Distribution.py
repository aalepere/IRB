"""
Object containing methods related to model distribution
"""

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from .Modelling.transform_utils import import_module_variable
from .research_utils import score_and_order_data

class Distribution:
    """ Distribution class set up """
    def __init__(self, data, company_size, output_flag, logger, for_prod_dir):
        self._data = data
        self.company_size = company_size
        self.output_flag = output_flag
        self.logger = logger
        self.calibration_parameters = import_module_variable(for_prod_dir, 'calibration_parameters')

    def show_all_distributions(self):
        """ Generate scores and show all distributions """
        self.generate_calibrated_scores()
        self.show_probability_distribution()
        self.show_hokoscale_distribution()

    def generate_calibrated_scores(self):
        """ Generate calibrated scores using the calibration parameters """
        self.score_df = score_and_order_data(self._data, self.output_flag, self.company_size)
        a = self.calibration_parameters['a']
        b = self.calibration_parameters['b']
        c = self.calibration_parameters['c']
        if 'threshold' in self.calibration_parameters.keys():
            d = self.calibration_parameters['d']
            e = self.calibration_parameters['e']
            threshold = self.calibration_parameters['threshold']
        else:
            d = 0
            e = 0
            threshold = 1000000000000
        self.score_df.loc[(self.score_df['score'] < threshold), 'calibrated_proba'] = 1 / (1 + np.exp(a * (self.score_df['score'] ** 2) + b * self.score_df['score'] + c))
        self.score_df.loc[(self.score_df['score'] >= threshold), 'calibrated_proba'] = d*np.exp(e*self.score_df['score'])
        self.score_df.loc[(self.score_df['calibrated_proba'] > 1), 'calibrated_proba'] = 0.99999999999

    def show_probability_distribution(self):
        """ Show probability distribution """
        plt.hist(self.score_df['calibrated_proba'], bins=100, color='#0504aa', alpha=0.7)
        plt.grid(axis='y', alpha=0.75)
        plt.xlabel('Calibrated probability')
        plt.ylabel('Frequency')
        plt.title('{} Probability Distribution'.format(self.company_size))
        plt.show()

    def add_1_to_25_hokoscale_to_scores(self):
        """ Adds 1 to 25 scale to scores dataframe """
        scale = [0.0000000,
                 0.0001314,
                 0.0001858,
                 0.0002628,
                 0.0003716,
                 0.0005256,
                 0.0007433,
                 0.0010511,
                 0.0014865,
                 0.0021022,
                 0.0029730,
                 0.0042045,
                 0.0059460,
                 0.0084090,
                 0.0118921,
                 0.0168179,
                 0.0237841,
                 0.0336359,
                 0.0475683,
                 0.0672717,
                 0.0951366,
                 0.1345434,
                 0.1902731,
                 0.2690869,
                 0.3805463,
                 1.0000000]
        self.score_df['bin125'] = pd.cut(self.score_df['calibrated_proba'], scale, labels=False) + 1

    def show_hokoscale_distribution(self):
        """ Show hokoscore distribution """
        self.add_1_to_25_hokoscale_to_scores()
        mean_score = self.score_df['calibrated_proba'].mean()
        bar_chart = self.score_df.groupby('bin125', as_index=False)[self.output_flag].count()
        plt.bar(bar_chart['bin125'], bar_chart[self.output_flag])
        plt.xlim((1, 25))
        plt.xlabel('Hokoscore 1-25 scale')
        plt.ylabel('Frequency')
        plt.title('{} Hokoscore distribution\nPD mean: {:.4f}'.format(self.company_size, mean_score))
        plt.show()
