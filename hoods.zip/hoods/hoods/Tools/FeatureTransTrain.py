"""
Object containing methods related to single self.feature analysis
"""

############################################
# Libraries required for self.featureTrans #
############################################
from functools import reduce
import pandas as pd
#pylint: disable=import-error
from joblib import Parallel, delayed
from .Modelling.transform_utils import import_module_variable, write_to_python_file
from .research_utils import replace_missing_with_central_tendency, remove_specific_value, group_values_together, winsorize_column, inverse_and_transform, discretize_column, transform_to_log_odds, scale_feature

#############################################################################################################################
# self.featureTrans class including all functions required for self.features transformation for both training and test sets #
#############################################################################################################################

class FeatureTransTrain:
    """ class FeatureTransTrain to be used for feature transformation """
    def __init__(self, data, output_flag, cores, logger, for_prod_dir):
        self._data = data
        self.output_flag = output_flag
        self.cores = cores
        self.logger = logger
        self.for_prod_dir = for_prod_dir
        self.trans_to_apply = import_module_variable(self.for_prod_dir, 'transformations_to_apply')

    def transform_scale_train_set(self):
        """ Apply transformation to all selected features based on the JSON """
        shape = self._data.shape
        bads = self._data[self.output_flag].sum()
        self.feature_objects_list = Parallel(backend='multiprocessing', n_jobs=self.cores)(delayed(self.transform_feature)(col) for col in self.trans_to_apply)
        self.merge_feature_dataframes()
        self.merge_and_write_dictionaries(1, 'central_tendency_mapping')
        self.merge_and_write_dictionaries(2, 'disc_bin_edges_mapping')
        self.merge_and_write_dictionaries(3, 'disc_own_bin_index_mapping')
        self.transform_to_log_odds()
        self.write_log_odds_mapping()
        self.scale_all_features()
        self.write_scale_mappings()
        self.logger.info('FeatTran : {} columns and {} rows have been removed'.format(shape[1] - self._data.shape[1], shape[0] - self._data.shape[0]))
        self.logger.info('FeatTran : {} bads have been dropped'.format(bads-self._data[self.output_flag].sum()))
        self.logger.info('FeatTran : Writing transformed data to data_sandbox/5_FeatTrans.csv')
        self._data.to_csv('data_sandbox/5_FeatTrans.csv', index=False, header=True)

    def transform_feature(self, feature):
        """ sequence for transforming features in the train set """
        self.logger.info('FeatTran : Transforming feature --> {}'.format(feature))

        #Create feature dataframe
        feature_df = self._data.loc[:, [self.output_flag, 'company_id', feature]]

        #Feature parameters from transformations to apply
        rep_method = self.trans_to_apply[feature]['replace_nans']['rep_method']
        remove_val = self.trans_to_apply[feature]['remove']['remove_val']
        cutoff = self.trans_to_apply[feature]['group']['cutoff']
        threshold = self.trans_to_apply[feature]['winsorize']['threshold']
        params = self.trans_to_apply[feature]['fit']['params']
        how = self.trans_to_apply[feature]['discretize']['how']
        seed = self.trans_to_apply[feature]['discretize']['seed']
        n = self.trans_to_apply[feature]['discretize']['n']
        method = self.trans_to_apply[feature]['discretize']['method']
        range_ = self.trans_to_apply[feature]['discretize']['range']
        weights = self.trans_to_apply[feature]['discretize']['weights']
        new_edges = self.trans_to_apply[feature]['discretize']['new_edges']
        own_bins = self.trans_to_apply[feature]['discretize']['own_bins']

        #Define default values
        feature_central_tendency = None
        feature_bin_edges = None
        feature_own_bin_index_list = None
        feature_log_odds = None
        feature_scale_metrics = None

        if own_bins:
            #Saving filtered company ID's and filtering dataframe
            filtered_data = feature_df[feature_df[feature].isin(own_bins)]
            feature_df = feature_df[~feature_df[feature].isin(own_bins)]
            if 'nan' not in own_bins:
                self.logger.info('...........Replacing missing values')
                feature_df, feature_central_tendency = replace_missing_with_central_tendency(dataframe=feature_df, column=feature, rep_method=rep_method)
            if self.trans_to_apply[feature]['remove']['apply']:
                self.logger.info('...........Remove value')
                feature_df = remove_specific_value(dataframe=feature_df, column=feature, remove_val=remove_val)
            if self.trans_to_apply[feature]['group']['apply']:
                self.logger.info('...........Group values')
                feature_df = group_values_together(dataframe=feature_df, column=feature, cutoff=cutoff)
            if self.trans_to_apply[feature]['winsorize']['apply']:
                self.logger.info('...........Winsorize')
                feature_df = winsorize_column(dataframe=feature_df, column=feature, threshold=threshold)
            self.logger.info('...........Discretize')
            feature_df, feature_bin_edges, feature_own_bin_index_list = discretize_column(dataframe=feature_df,\
                    column=feature, output_flag=self.output_flag, custom_bin_edges=new_edges, own_bins=own_bins, how=how, seed=seed, n=n,\
                    method=method, range_=range_, weights=weights, filtered_data=filtered_data, transform_flag=True)

        else:
            self.logger.info('...........Replacing missing values')
            feature_df, feature_central_tendency = replace_missing_with_central_tendency(dataframe=feature_df, column=feature, rep_method=rep_method)
            if self.trans_to_apply[feature]['remove']['apply']:
                self.logger.info('...........Remove value')
                feature_df = remove_specific_value(dataframe=feature_df, column=feature, remove_val=remove_val)
            if self.trans_to_apply[feature]['group']['apply']:
                self.logger.info('...........Group values')
                feature_df = group_values_together(dataframe=feature_df, column=feature, cutoff=cutoff)
            if self.trans_to_apply[feature]['winsorize']['apply']:
                self.logger.info('...........Winsorize')
                feature_df = winsorize_column(dataframe=feature_df, column=feature, threshold=threshold)
            if self.trans_to_apply[feature]['fit']['apply']:
                self.logger.info('...........Fit')
                feature_df = inverse_and_transform(dataframe=feature_df, column=feature, params=params, output_flag=self.output_flag)
            if self.trans_to_apply[feature]['discretize']['apply']:
                self.logger.info('...........Discretize')
                feature_df, feature_bin_edges = discretize_column(dataframe=feature_df, column=feature,\
                        output_flag=self.output_flag, custom_bin_edges=new_edges, own_bins=own_bins, how=how, seed=seed, n=n,\
                        method=method, range_=range_, weights=weights, filtered_data=None, transform_flag=True)

        return feature_df, feature_central_tendency, feature_bin_edges, feature_own_bin_index_list

    def merge_feature_dataframes(self):
        ''' merge dataframes in feature_objects_list '''
        feature_dataframe_list = []
        for feature_object in self.feature_objects_list:
            feature_dataframe_list.append(feature_object[0])
        self._data = reduce(lambda x, y: pd.merge(x, y, how='inner', on=['company_id', self.output_flag]), feature_dataframe_list)

    def merge_and_write_dictionaries(self, index, feature_mapping_name):
        ''' merge dictionaries in feature_objects_list and write them to forprod '''
        feature_mapping = {}
        for feature_object in self.feature_objects_list:
            if feature_object[index] is not None:
                feature_mapping.update(feature_object[index])
        self.logger.info('FeatTran : Writing to {}.py'.format(feature_mapping_name))
        write_to_python_file(feature_mapping, feature_mapping_name, self.for_prod_dir)

    def transform_to_log_odds(self):
        """ Log odds mapping for all features to ensure the score currency is the same for the score function """
        self.log_odds_mapping = {}
        for feature in [col for col in self._data.columns if col not in ['company_id', self.output_flag]]:
            self.logger.info('FeatTran : Transforming feature to log odds --> {}'.format(feature))
            self._data, feature_log_odds = transform_to_log_odds(self._data, feature, self.output_flag)
            self.log_odds_mapping.update(feature_log_odds)

    def write_log_odds_mapping(self):
        ''' write log_odds mappings to ForProd '''
        self.logger.info('FeatTran : Writing log odds dictionary mappings to log_odds_mapping.py')
        write_to_python_file(self.log_odds_mapping, 'log_odds_mapping', self.for_prod_dir)

    def scale_all_features(self):
        """ Standard scalar to ensure that all feature are all on the same scale for coefficients
        comparison """
        self.scale_metrics_mapping = {}
        for feature in [col for col in self._data.columns if col not in ['company_id', self.output_flag]]:
            self.logger.info('FeatTran : Scaling feature --> {}'.format(feature))
            self._data, feature_scale_metrics_mapping = scale_feature(self._data, feature)
            self.scale_metrics_mapping.update(feature_scale_metrics_mapping)

    def write_scale_mappings(self):
        ''' write scale mappings to ForProd '''
        self.logger.info('FeatTran : Writing scale dictionary mappings to scale_metrics_mapping.py')
        write_to_python_file(self.scale_metrics_mapping, 'scale_metrics_mapping', self.for_prod_dir)
