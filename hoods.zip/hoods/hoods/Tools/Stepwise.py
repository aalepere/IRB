"""
Description: Runs stepwise analysis to assess the best combination of features for the model
"""

#############
# Libraries #
#############
import subprocess
import os
import sys
import re
import pkg_resources

##################################################################
# Stepwise class including all functions required for R analysis #
##################################################################
class Stepwise:
    """ used for stepwise regression """

    def __init__(self, data, logger, output_flag, package_flag=True):
        """ @param data {dataframe}, output_flag {string} """
        self._data = data
        self.logger = logger
        self.output_flag = output_flag
        self.package_flag = package_flag
        if os.path.isfile('tmp_stepwise_data.csv'):
            os.remove('tmp_stepwise_data.csv')
        data.loc[:, data.columns != 'company_id'].to_csv('tmp_stepwise_data.csv')
        self.load_r_file_paths()
        self.create_r_name_mapping()

    def load_r_file_paths(self):
        """ loads the r file paths """
        if self.package_flag:
            self.r_step_back = pkg_resources.resource_filename('hoods', 'Tools/R_Stepwise_back_reg.R')
            self.r_names = pkg_resources.resource_filename('hoods', 'Tools/R_make_names.R')
        else:
            self.r_step_back = 'Tools/R_Stepwise_back_reg.R'
            self.r_names = 'Tools/R_make_names.R'

    def create_r_name_mapping(self):
        """ creates a mapping for features as r alters their state in its output """
        self.features_dumb_r_map = {}
        for old_col in self._data.columns:
            result = subprocess.run(['Rscript', self.r_names, old_col], stdout=subprocess.PIPE)
            new_col = result.stdout.decode("utf-8")
            new_col = eval(new_col.split()[1])
            self.features_dumb_r_map[new_col] = old_col

    def backwards_regression(self):
        """ generates the backwards regression results from R and returns a list of features to remove from model """
        self.logger.info('Stepwise : Started running backwards regression')
        result = subprocess.run(['Rscript', self.r_step_back, 'tmp_stepwise_data.csv',\
                '{} ~.'.format(self.output_flag)], stdout=subprocess.PIPE)
        str_output = result.stdout.decode("utf-8")
        if self.check_output_ok(str_output):
            with open("data_sandbox/stepwise_back_model.txt", "w") as f:
                f.write(str_output)
            variables_not_clean = re.findall(r'{}.+?family'.format(self.output_flag), str_output, re.DOTALL)[0]
            best_model_features = [i.strip() for i in variables_not_clean.split('liq_flg ~')[1].split('family')[0].replace('\n', '').replace(',', '').split('+')]
            best_model_features = [i for i in best_model_features if i]
            best_model_features = [self.features_dumb_r_map[i] for i in best_model_features]
            features_to_remove = [col for col in self._data.columns if col not in best_model_features]
            self.logger.info('Stepwise : Finished running backwards regression and returned removals')
        os.remove('tmp_stepwise_data.csv')
        return features_to_remove

    def check_output_ok(self, output):
        """ function for checking the output from R script """
        if output[0:11] == 'Fatal error' and output[-26:] == 'No such file or directory\n':
            self.logger.critical('Stepwise : The model file attempted to be run does not exist')
            sys.exit()
        elif not output:
            self.logger.critical('Stepwise : The script within the R file selected has failed to run')
            sys.exit()
        return True
