"""
Description: Generate single feature analysis notebook for all features
"""

#############
# Libraries #
#############
import json
import os
from .Modelling.transform_utils import write_to_python_file

###################################################################################
# GiniAnalysis class including all functions required for predictive power review #
###################################################################################

class SingleFeatureAnalysis:
    """ SingleFeatureAnalysis class containing methods related to the generating the analysis """

    def __init__(self, data, output_flag, company_size, for_prod_dir, logger):
        """ data {dataframe}, output_flag {string}"""
        self._data = data
        self.output_flag = output_flag
        self.company_size = company_size
        self.for_prod_dir = for_prod_dir
        self.logger = logger
        self._data = data[~data['to_remove']].sort_values('gini_coeff_abs', ascending=False)

    def create_notebook(self):
        """ create notebook and write to file """
        # Send warning message if about to overwite old trans to apply or sfa
        transform_to_apply_filepath = f'{self.for_prod_dir}/transformations_to_apply.py'
        single_feature_analysis_filepath = f'Single_feature_analysis_{self.company_size}.ipynb'
        if os.path.exists(transform_to_apply_filepath) or os.path.exists(single_feature_analysis_filepath):
            input("WARNING: You are about to overwrite previous transformations to apply files, press enter to continue")

        # Run Single feature analysis
        self.logger.info('SingFeat : Creating empty transformations to apply file')
        write_to_python_file({}, 'transformations_to_apply', '{}'.format(self.for_prod_dir))
        notebook_header = self.create_notebook_header()
        self.logger.info('SingFeat : Starting notebook feature list')
        feature_notebook = self.create_feature_notebook_list()
        self.notebook = notebook_header + feature_notebook
        self.logger.info('SingFeat : Joining notebook together')
        self.create_notebook_wrapper()
        self.logger.info('SingFeat : Writing notebook to file')
        with open(single_feature_analysis_filepath, 'w') as fp:
            json.dump(self.wrapper, fp)

    def create_notebook_wrapper(self):
        """ create wrapper for top and bottom of notebook """
        self.wrapper = {
            "cells": self.notebook,
            "metadata": {
                "kernelspec": {
                    "display_name": "Python 3",
                    "language": "python",
                    "name": "python3"
                },
                "language_info": {
                    "codemirror_mode": {
                        "name": "ipython",
                        "version": 3
                        },
                    "file_extension": ".py",
                    "mimetype": "text/x-python",
                    "name": "python",
                    "nbconvert_exporter": "python",
                    "pygments_lexer": "ipython3",
                    "version": "3.7.3"
                    }
                },
            "nbformat": 4,
            "nbformat_minor": 2
            }

    def create_notebook_header(self):
        """ Create feature header """
        notebook_header_list = [
            {
                "cell_type": "markdown",
                "metadata": {},
                "source": ["# Single Feature Analysis: {}\n".format(self.company_size)]
                },
            {
                "cell_type": "markdown",
                "metadata": {},
                "source": ["## 1 - Libraries"]
                },
            {
                "cell_type": "code",
                "execution_count": 1,
                "metadata": {},
                "outputs": [],
                "source": [
                    "%matplotlib inline\n",
                    "import pandas as pd\n",
                    "from hoods.Tools.research_utils import full_viz\n",
                    "df = pd.read_csv('data_sandbox/3_DataTopFeatures.csv')"
                    ]
                }
            ]
        return notebook_header_list

    def create_feature_notebook_list(self):
        """ create notebook list with features """
        execution_count = 2
        feature_notebook_list = []
        for _, row in self._data.iterrows():
            self.logger.info('SingFeat : Adding feature {} to notebook'.format(row['column_name']))
            feature_header = self.create_feature_header(row['column_name'], row['gini_coeff_abs'])
            feature_visualisation = self.create_feature_visualisation(row['column_name'], execution_count)
            feature_notebook_list = feature_notebook_list + feature_header + feature_visualisation
            execution_count += 2
        return feature_notebook_list

    def create_feature_header(self, feature, gini):
        """ Create feature header """
        feature_header_list = [
            {
                "cell_type": "markdown",
                "metadata": {},
                "source": ["# Feature: {}".format(feature)]
                },
            {
                "cell_type": "markdown",
                "metadata": {},
                "source": ["## Gini: {}".format(gini)]
                }
            ]
        return feature_header_list

    def create_feature_visualisation(self, feature, execution_count):
        """ Create feature visualisation """
        feature_visualisation_list = [
            {
                "cell_type": "code",
                "execution_count": execution_count,
                "metadata": {
                    "tags": [
                        "parameters"
                    ]
                },
                "outputs": [],
                "source": [
                    "# Parameters\n",
                    "output_flag = '{}'\n".format(self.output_flag),
                    "for_prod_dir = 'ForProd/'\n",
                    "feature = '{}'\n".format(feature),
                    "bin_values = []\n",
                    "nan_rep_method = 'median'\n",
                    "remove_value = False\n",
                    "remove_val = 0\n",
                    "group_values = False\n",
                    "cutoff = 0\n",
                    "winsorize = False\n",
                    "threshold = 0.01\n",
                    "fit = False\n",
                    "params = 2\n",
                    "discretize = False\n",
                    "how = 'quantile'\n",
                    "seed = 7\n",
                    "n = 5\n",
                    "method = 'auto'\n",
                    "range_ = None\n",
                    "weights = None\n",
                    "new_edges = []\n",
                    "write_params = False\n"
                    ]
                },
            {
                "cell_type": "code",
                "execution_count": execution_count+1,
                "metadata": {},
                "outputs": [],
                "source": [
                    "full_viz(\n",
                    "    data=df, for_prod_dir=for_prod_dir, remove_value=remove_value, feature=feature, params=params,\\\n",
                    "    threshold=threshold, seed=seed, bin_values=bin_values, remove_val=remove_val, cutoff=cutoff,\\\n",
                    "    group_values=group_values, nan_rep_method=nan_rep_method, new_edges=new_edges, discretize=discretize, how=how,\\\n",
                    "    n=n, range_=range_, weights=weights, winsorize=winsorize, fit=fit, output_flag=output_flag,\\\n",
                    "    write_params=write_params, method=method)"
                    ]
                }
            ]
        return feature_visualisation_list
