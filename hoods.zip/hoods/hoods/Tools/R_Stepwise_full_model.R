args = commandArgs(trailingOnly=TRUE)
if (length(args)<3) {
      stop("At least two arguments must be supplied", call.=FALSE)
}
MyData <- read.csv(file=args[1], header=TRUE, sep=",")
MyData$X <- NULL
fullmod <- glm(as.formula(args[2]), family = binomial, data = MyData)
summary(fullmod)
nonmod <- glm(as.formula(args[3]), family = binomial, data = MyData)
summary(nonmod)
