args = commandArgs(trailingOnly=TRUE)
make.names(args)
