"""
inittest2==1.1.0
Description: List of all functions required for Data Preparation for Single feature analysis
"""

###########################################
# Libraries required for Data Preparation #
###########################################
import json
from .research_utils import compute_default_rate
from .Modelling.transform_utils import write_to_python_file

###############################################################################
# DataPrepTrain class including all functions required for data preparation #
###############################################################################

class DataPrepTrain:
    ''' Data Prep Train is a sub class of data prep test. It replaces select missing values with default values, converts categorical values to numerical ones and
        removes columns with too many missing values
    '''
    def __init__(self, data, output_flag, logger, missing_threshold, for_prod_dir, datasets_dir):
        self._data = data
        self.output_flag = output_flag
        self.logger = logger
        self.missing_threshold = missing_threshold
        self.for_prod_dir = for_prod_dir
        self.datasets_dir = datasets_dir

    def prepare_train_data(self):
        ''' method to run all transformation methods in sequence '''
        self.logger.info("DataPrep : Starting train data preparation")
        self.write_default_value_mappings()
        self.write_cat_to_num_mappings()
        self.remove_cols_too_many_missing()
        for feature in [i for i in self._data.columns if i not in [self.output_flag, 'company_id']]:
            self._data[feature] = self._data[feature].astype('float64')
        self._data.to_csv('data_sandbox/1_DataPrepTrain.csv', index=False, header=True)
        self.logger.info('DataPrep : Writing df to data_sandbox/1_DataPrepTrain.csv')

    def write_default_value_mappings(self):
        ''' writes the default train set value mappings into a python file '''
        self.convert_missing_values_to_default()
        self.logger.info('DataPrep : Writing mappings for default values to {}default_value_mapping.py'.format(self.for_prod_dir))
        write_to_python_file(self.default_value_mappings, 'default_value_mapping', self.for_prod_dir)

    def convert_missing_values_to_default(self):
        ''' Replace missing values with default values selected '''
        self.load_default_value_features()
        self.logger.info('DataPrep : Converting missing values to default values selected')
        self.default_value_mappings = {}
        for cols_list in self.cols_to_replace:
            default_value = cols_list['value']
            for col in cols_list['columns']:
                if col in self._data:
                    self.default_value_mappings.update({col: default_value})
                    self._data[col].fillna(default_value, inplace=True)

    def load_default_value_features(self):
        ''' loads a list called cols_to_replace which are features that include missing values to be defaulted to a chosen value '''
        self.logger.info('DataPrep : Loaded default value for each feature from {}data_prep_column_clean.json[DefaultValueReplace]'.format(self.datasets_dir))
        with open('{}data_prep_column_clean.json'.format(self.datasets_dir)) as data_prep:
            self.cols_to_replace = json.load(data_prep)['DefaultValueReplace']

    def write_cat_to_num_mappings(self):
        ''' writes the categorical train set value mappings into a python file '''
        self.convert_cat_to_num_features()
        self.logger.info('DataPrep : Writing mappings for categorical values to {}cat_to_num_mapping.py '.format(self.for_prod_dir))
        write_to_python_file(self.cat_to_num_mappings, 'cat_to_num_mapping', self.for_prod_dir)

    def convert_cat_to_num_features(self):
        ''' converts the categorical features into numerical features for the train set '''
        self.load_categorical_features()
        self.logger.info('DataPrep : Converting categorical features to numerical features')
        self.cat_to_num_mappings = {}
        for feat in self.non_numeric_cols:
            self._data[feat].fillna('nan', inplace=True)
            self._data = compute_default_rate(self._data, feat, self.output_flag)
            self._data['{}_cat'.format(feat)] = self._data['{}_DR'.format(feat)].rank(method='dense', ascending=True, na_option='keep')#.astype('float64')
            self.cat_to_num_mappings[feat] = self._data[[feat, '{}_cat'.format(feat)]].set_index(feat).to_dict()
            self._data.drop(columns=['{}'.format(feat), '{}_DR'.format(feat)], inplace=True)

    def load_categorical_features(self):
        ''' loads a list called non_numeric_cols which are features to be categorised '''
        self.logger.info('DataPrep : Loaded Non Numeric Cols from {}data_prep_column_clean.json[NonNumericCols]'.format(self.datasets_dir))
        with open('{}data_prep_column_clean.json'.format(self.datasets_dir)) as data_prep:
            self.non_numeric_cols = json.load(data_prep)['NonNumericCols']

    def remove_cols_too_many_missing(self):
        ''' remove columns in the dataset that have too many missing value, a threshold is to be set '''
        self.logger.info('DataPrep : Removing columns with more than {} rows missing'.format(self.missing_threshold))
        num_required_for_no_removal = round(len(self._data)*self.missing_threshold)
        self.logger.info('DataPrep : {} columns have been removed'.format(len(self._data.columns) - len(self._data.dropna(thresh=num_required_for_no_removal, axis=1).columns)))
        self._data.dropna(thresh=num_required_for_no_removal, axis=1, inplace=True)
