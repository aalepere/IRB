"""
Object containing methods related to the pre model analysis
"""

#############################################
# Libraries required for Pre Model Analysis #
#############################################
import pandas as pd
from .Modelling.transform_utils import import_module_variable

################################################################################################
# self.preModelAnalysis class including all functions required for both training and test sets #
################################################################################################

class PreModelAnalysis:
    ''' takes training dataset and test dataset and edits them based on the pre model analysis '''
    def __init__(self, for_prod_dir, logger, output_flag, data_path=None, data_path_out=None):
        self.logger = logger
        self.logger.info(f'PreModel : Reading data from {data_path}')
        self._data = pd.read_csv(data_path, low_memory=False)
        self.data_path_out = data_path_out
        self.for_prod_dir = for_prod_dir
        self.output_flag = output_flag

    def remove_features_and_write_data(self):
        ''' removes features and writes the new datasets to csvs '''
        self.remove_features()
        self.write_data_to_csv()

    def remove_features(self):
        ''' loads json with features to remove and removes them from the dataset '''
        prod_features = import_module_variable(self.for_prod_dir, 'prod_features')
        cols_to_keep = prod_features['prod_features'] + [self.output_flag, 'company_id']
        self.logger.info(f'PreModel : Removing {len(cols_to_keep)} columns from train and test data')
        self._data = self._data[cols_to_keep]

    def write_data_to_csv(self):
        ''' writes test and train dataset to csv files in the data sandbox '''
        self._data.to_csv(self.data_path_out, index=False)
