"""
Object containing methods related to model calibration
"""

import pandas as pd
import numpy as np
from scipy.optimize import minimize
import matplotlib.pyplot as plt
from .research_utils import score_and_order_data
from .Modelling.transform_utils import write_to_python_file

class Calibration:
    """ Calibration class set up """
    def __init__(self, data, bin_number, performance_window, anchor_point, add_constraint, company_size, output_flag, logger, for_prod_dir):
        self._data = data
        self.bin_number = bin_number
        self.performance_window = performance_window
        self.anchor_point = anchor_point
        self.add_constraint = add_constraint
        self.company_size = company_size
        self.output_flag = output_flag
        self.logger = logger
        self.for_prod_dir = for_prod_dir

    def run_calibration(self):
        """ Runs functions to calibrate the model """
        self.discretize_score_data()
        self.create_calibration_dataframe()
        self.calibrate_model()
        print(self.cal_df)
        self.plot_pd_fit()

    def discretize_score_data(self):
        """ create a score dataframe and discretize the data """
        score_df = score_and_order_data(self._data, self.output_flag, self.company_size)
        score_df['bin'] = pd.cut(score_df.index, bins=self.bin_number, labels=False)
        self.grouped_bins = score_df.groupby(['bin'], as_index=False)

    def create_calibration_dataframe(self):
        """ Creates dataframe used for calibration """
        self.cal_df = pd.DataFrame()
        self.cal_df['bin'] = self.grouped_bins[self.output_flag].count()['bin'].astype(float)
        self.cal_df['total_companies'] = self.grouped_bins[self.output_flag].count()[self.output_flag].astype(float)
        self.cal_df['bads'] = self.grouped_bins[self.output_flag].sum()[self.output_flag].astype(float)
        self.cal_df['goods'] = (self.cal_df['total_companies'] - self.cal_df['bads']).astype(float)
        self.cal_df['median_score'] = self.grouped_bins['score'].median()['score']
        self.cal_df['12_month_bads'] = (1 - ((self.cal_df['goods']/self.cal_df['total_companies'])**(12/self.performance_window)))*self.cal_df['total_companies']
        self.cal_df['12_month_goods'] = self.cal_df['total_companies'] - self.cal_df['12_month_bads']
        rdf_sample = self.cal_df['12_month_bads'].sum() / self.cal_df['total_companies'].sum()
        bad_weight = self.anchor_point / rdf_sample
        good_weight = (1 - self.anchor_point) / (1 - rdf_sample)
        self.cal_df['pd_in_bin'] = (self.cal_df['12_month_bads']*bad_weight) / ((self.cal_df['12_month_goods']*good_weight) + (self.cal_df['12_month_bads']*bad_weight))

    def calibrate_model(self):
        """ Calibrates the model based on specified parameters """
        x0 = [0.0, 0.0, 0.0]
        cons = {'type': 'ineq', 'fun': lambda x: 0.0001 - abs((sum(self.calculate_fitted_pd(x, self.cal_df['median_score'])*self.cal_df['total_companies'])/sum(self.cal_df['total_companies'])) - self.anchor_point)}
        if self.add_constraint:
            res_lsq = minimize(self.objective_function, x0, args=(self.cal_df['median_score'], self.cal_df['pd_in_bin']), method='SLSQP', constraints=cons)
        else:
            res_lsq = minimize(self.objective_function, x0, args=(self.cal_df['median_score'], self.cal_df['pd_in_bin']), method='SLSQP')
        self.cal_df['fitted_pd'] = self.calculate_fitted_pd(res_lsq.x, self.cal_df['median_score'])
        calibration_parameters = {'a': res_lsq.x[0], 'b': res_lsq.x[1], 'c': res_lsq.x[2]}
        write_to_python_file(calibration_parameters, 'calibration_parameters', self.for_prod_dir)

    def objective_function(self, x, t, y):
        """ objective function to be used in minimising sum of squares """
        fitted_pd = self.calculate_fitted_pd(x, t)
        return sum(np.square(np.log(fitted_pd/y)))

    def calculate_fitted_pd(self, x, t):
        """ function used to calculate the fitted probability of default """
        return 1 / (1 + np.exp(x[0]*(t**2) + x[1]*t + x[2]))

    def plot_pd_fit(self):
        """ Show plot of fitted PD against PD in bin """
        plt.figure()
        plt.plot(self.cal_df['median_score'], self.cal_df['pd_in_bin'], color='red', label='pd_in_bin')
        plt.plot(self.cal_df['median_score'], self.cal_df['fitted_pd'], color='blue', label='fitted_pd')
        plt.yscale('log')
        plt.xlabel('Score')
        plt.ylabel('pd')
        plt.title('pd in bin vs fitted pd')
        plt.legend()
        plt.show()
