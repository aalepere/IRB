""" Logistic Regression Class with ability to penalise coefficients """

from sklearn.linear_model import LogisticRegression
import numpy as np
import pandas as pd

class LogisticRegressionWithPenalties:
    """ Custom logistic regression class that allows penalising of coefficients """
    def __init__(self, lr=0.01, num_iter=100000, fit_intercept=True, verbose=False, model_flag=False):
        self.lr = lr
        self.num_iter = num_iter
        self.fit_intercept = fit_intercept
        self.verbose = verbose
        self.model_flag = model_flag

    def __add_intercept(self, X):
        intercept = np.ones((X.shape[0], 1))
        return np.concatenate((X, intercept), axis=1)

    def __sigmoid(self, z):
        return 1 / (1 + np.exp(-z))

    def __loss(self, h, y):
        return (-y * np.log(h) - (1 - y) * np.log(1 - h)).mean()

    def __prepare_coefficients_for_freezing(self):
        cls = LogisticRegression()
        cls.fit(self.X, self.y)
        self.feature_list = list(self.X.columns)
        self.theta = cls.coef_
        self.indexes_to_freeze = []
        for feature in self.penalty_dictionary:
            index = self.feature_list.index(feature)
            self.indexes_to_freeze.append(index)
            self.theta[0][index] = self.theta[0][index] * self.penalty_dictionary[feature]
        if self.fit_intercept:
            self.theta = np.append(self.theta, [0])
            self.feature_list.append('intercept')

    def __iteration_dataframe(self):
        if 'intercept' in self.feature_list:
            coeff_df = pd.DataFrame({'feature': self.feature_list[:-1], 'coefficient': self.theta[:-1]})
        else:
            coeff_df = pd.DataFrame({'feature': self.feature_list, 'coefficient': self.theta})
        coeff_df['absolute_coeff'] = abs(coeff_df['coefficient'])
        coeff_df['pct'] = coeff_df['absolute_coeff']/sum(coeff_df['absolute_coeff'])
        coeff_df.drop(columns=['absolute_coeff'], inplace=True)
        coeff_df.sort_values('pct', ascending=False, inplace=True)
        print(coeff_df)

    def fit(self, X, y, penalty_dictionary):
        """ Fit method for logistic regression with loop for penalisation """
        self.X = X
        self.y = y
        self.penalty_dictionary = penalty_dictionary
        self.__prepare_coefficients_for_freezing()
        X = np.array(X.values.tolist())
        y = np.array([a for b in self.y.values.tolist() for a in b])
        if self.fit_intercept:
            X = self.__add_intercept(X)

        print('Iterating to generate logistic regression with penalties model')
        for i in range(self.num_iter):
            if i % 1000 == 0 and i != 0:
                if not self.model_flag:
                    print(f'Loss at iteration {i} is {loss}')
                    self.__iteration_dataframe()
            # Get the score and take the sigmoid to generate a value
            # between 0 and 1
            z = np.dot(X, self.theta)
            h = self.__sigmoid(z)
            # Calculate the gradient of the function that minimises the difference
            # between the predicted probability h and the actual probability y
            gradient = np.dot(X.T, (h - y)) / y.size
            # FREEZE THE CHANGE IN THE GRADIENT FOR THE INDEXES that we want to penalise
            gradient[self.indexes_to_freeze] = 0
            self.theta -= self.lr * gradient

            z = np.dot(X, self.theta)
            h = self.__sigmoid(z)
            loss = self.__loss(h, y)

            if (self.verbose and i % 10000 == 0 and not self.model_flag):
                print('loss: {loss} \t')

        if not self.model_flag:
            print(f'Final model at iteration {self.num_iter}')
            self.__iteration_dataframe()
        
        # Coefficients and intercept declaration
        self.coef_ = np.array([list(self.theta[:-1])])
        self.intercept_ = np.array([self.theta[-1]])

    def predict_proba(self, X):
        """ Predict proba method for logistic regression with penalties """
        if self.fit_intercept:
            X = self.__add_intercept(X)
        prob_x_array = self.__sigmoid(np.dot(X, self.theta))
        proba_list = []
        for i in range(len(prob_x_array)):
            prob_x = prob_x_array[i]
            prob_not_x = 1-prob_x
            proba_list.append([prob_not_x, prob_x])
        return np.array(proba_list)

    def predict(self, X):
        """ Predict proba for logistic regression with penalties """
        return self.predict_proba(X)
