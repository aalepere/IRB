"""
Description: Class containing all functions required for Data Preparation for Single feature analysis
"""
###########################################
# Libraries required for Data Preparation #
###########################################
import numpy as np
from .transform_utils import import_module_variable

############################################################################
# DataPrepTest class including all functions required for data preparation #
############################################################################

class DataPrepTest:
    ''' Data Preparation replaces columns with median values and scales categorical data for test set'''
    def __init__(self, data, for_prod_dir, output_flag, logger):
        self._data = data
        self.for_prod_dir = for_prod_dir
        self.output_flag = output_flag
        self.logger = logger

    def prepare_test_data(self):
        ''' Method to run all transformation methods in sequence '''
        self.logger.info('DataPrep : Starting Test Data Preparation')
        # Load the default mappings from ForProd.default_value_mapping
        self.load_train_data_default_value_mappings()
        # Replace nans in test data with default value mappings, e.g. a nan financials will often be defaulted to 0
        self.convert_test_data_with_default_value_mappings()
        # Load the mappings of categories to integers from ForProd.cat_to_num_mapping
        self.load_train_data_cat_to_num_mappings()
        # Replace categories with mapped integer. For example, the for the sic_1_group feature, the category
        # Agriculture could be mapped to 2
        self.convert_test_data_with_cat_to_num_mappings()

    def load_train_data_default_value_mappings(self):
        ''' Load default value mappings from train set
            Contains rules on how to default nan values '''
        self.logger.info('DataPrep : Mappings from default value data in train set loaded from {}default_value_mapping.py'.format(self.for_prod_dir))
        # Loads the default value mapping from ForProd.default_value_mapping
        self.default_value_mappings = import_module_variable(self.for_prod_dir, 'default_value_mapping')

    def convert_test_data_with_default_value_mappings(self):
        ''' Replaces the missing values of the features contained in cols_to_replace with their default value '''
        self.logger.info('DataPrep : Mapping default values using mapping from train set')
        for feat in self._data:
            if feat in self.default_value_mappings:
                default_value = self.default_value_mappings[feat]
                self._data[feat].fillna(default_value, inplace=True)

    def load_train_data_cat_to_num_mappings(self):
        ''' Load category to number mappings from train set '''
        self.logger.info('DataPrep : Mappings from categorical data in train set loaded from {}cat_to_num_mapping.py'.format(self.for_prod_dir))
        # Loads the default value mapping from ForProd.cat_to_num_mapping
        self.cat_to_num_mappings = import_module_variable(self.for_prod_dir, 'cat_to_num_mapping')

    def convert_test_data_with_cat_to_num_mappings(self):
        ''' Converts the categorical feature values into numerical values according to the mapping made with the train set '''
        self.logger.info('DataPrep : Converting test values using categorical mappings from train set')
        for feat in self._data:
            if feat in self.cat_to_num_mappings:
                # Replace NaN with nan, as we have called it this in the cat_to_num_mappings file ( e.g. {'nan':1.0 } )
                # and make this step obsolete
                self._data[feat].fillna('nan', inplace=True)
                # Replace category with mapping
                self._data['{}_cat'.format(feat)] = self._data[feat].astype('str').replace(self.cat_to_num_mappings[feat]['{}_cat'.format(feat)])
                # Replace any category that is not mapped with nan
                self._data['{}_cat'.format(feat)] = self._data.apply(lambda row: np.nan if isinstance(row['{}_cat'.format(feat)], str) else row['{}_cat'.format(feat)], axis=1)
                # Drop the non mapped column
                self._data.drop(columns=[feat], axis=1, inplace=True)
                try:
                    self._data['{}_cat'.format(feat)].replace({r'.*':np.nan}, regex=True, inplace=True)
                except TypeError:
                    # If no strings, then move on
                    pass
