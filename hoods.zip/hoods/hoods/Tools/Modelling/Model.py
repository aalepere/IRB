"""
Object containing methods related to modelling
"""
from sklearn.linear_model import LogisticRegression
from .LogisticRegressionWithPenalties import LogisticRegressionWithPenalties
from .transform_utils import import_module_variable, compute_dataset_gini, prep_train_and_test_set, write_to_python_file, create_model_dataframe

class Model:
    """ Model class set up with training and test set """
    def __init__(self, train_set, test_set, output_flag, logger, for_prod_dir, company_size):
        self._X_train, self._X_test, self._y_train, self._y_test =\
                prep_train_and_test_set(train_set, test_set, output_flag)
        self.logger = logger
        self.for_prod_dir = for_prod_dir
        self.company_size = company_size
        self.model_parameters = import_module_variable(self.for_prod_dir, 'model_parameters')

    def run_all_functions(self):
        """ Runs all functions within model """
        self.create_model()
        self.summarise_model()
        self.pickle_model()
        self.write_prod_coefficients()

    def create_model(self):
        """ Create model dependant on type from model parameters """

        model_type = self.model_parameters['type']

        if model_type == 'regular':
            penalty = self.model_parameters['penalty']
            C = self.model_parameters['C']
            self.clf = LogisticRegression(penalty=penalty, C=C)
            self.clf.fit(self._X_train, self._y_train)
            self.train_score = self.clf.score(self._X_train, self._y_train)
            self.test_score = self.clf.score(self._X_test, self._y_test)
        elif model_type == 'penalising':
            iterations = self.model_parameters['iterations']
            penalty_dict = self.model_parameters['penalty_dictionary']
            self.clf = LogisticRegressionWithPenalties(num_iter=iterations, model_flag=True)
            self.clf.fit(self._X_train, self._y_train, penalty_dict)
            self.train_score = 'NA for penalising'
            self.test_score = 'NA for penalising'

    def summarise_model(self):
        """ Prints out a summary of the results from the model """
        #TRAIN
        train_gini = compute_dataset_gini(self.clf, self._X_train, self._y_train)
        self.logger.info(f'Train accuracy score is {self.train_score}')
        self.logger.info(f'Train gini is {train_gini}')
        self.plot_roc_curve(self._X_train, self._y_train, 'Train')
        # TEST
        test_gini = compute_dataset_gini(self.clf, self._X_test, self._y_test)
        self.logger.info(f'Test accuracy score is {self.test_score}')
        self.logger.info(f'Test gini is {test_gini}')
        self.plot_roc_curve(self._X_test, self._y_test, 'Test')
        self.logger.info(f'MODEL PARAMETERS = {self.model_parameters}')
        print(create_model_dataframe(self.clf, self._X_train))

    def plot_roc_curve(self, X, y, dataset):
        """ Plot the ROC curve for a dataset (string is train or test) """
        import matplotlib.pyplot as plt
        from sklearn import metrics
        y_score_tr = self.clf.predict_proba(X)
        fpr, tpr, _ = metrics.roc_curve(y, y_score_tr[:, 1])
        gini = compute_dataset_gini(self.clf, X, y)

        plt.figure()
        lw = 2

        plt.plot(
            fpr,
            tpr,
            color='darkorange',
            lw=lw,
            label=f'ROC curve (Gini = {gini})')

        plt.plot([0, 1], [0, 1], color='navy', lw=lw, linestyle='--')
        plt.xlim([0.0, 1.0])
        plt.ylim([0.0, 1.05])
        plt.xlabel('False Positive Rate')
        plt.ylabel('True Positive Rate')
        plt.title(f'Receiver operating characteristic - {dataset}')
        plt.legend(loc="lower right")
        plt.show()

    def pickle_model(self):
        """ Pickles the model and saves it in the current directory """
        import pickle
        with open(f'CreditModel_{self.company_size}.p', 'wb') as outfile:
            pickle.dump(self.clf, outfile)
        self.logger.info(f'Pickling model and storing in current directory')

    def write_prod_coefficients(self):
        """ Writes prod coefficients to for prod """
        feature_list = self._X_train.columns.tolist() + ['intercept']
        theta = self.clf.coef_.tolist()[0] + [self.clf.intercept_.tolist()[0]]
        prod_coefficients = dict(zip(feature_list, theta))
        write_to_python_file(prod_coefficients, 'prod_coefficients', self.for_prod_dir)
        self.logger.info(f'Writing prod coefficients to {self.for_prod_dir}')

    def confusion_matrix(self):
        """ Plots the confusion matrix for the test set """
        from sklearn import metrics
        import seaborn as sns
        import matplotlib.pyplot as plt
        predictions = self.clf.predict(self._X_test)
        cm = metrics.confusion_matrix(self._y_test, predictions)
        sns.heatmap(cm, annot=True, fmt=".3f", linewidths=.5, square=True, cmap='Blues_r')
        plt.ylabel('Actual label')
        plt.xlabel('Predicted label')
