''' These lines of code are used to transform raw data using the parameters learning during training '''

import os
import importlib
import sys

def import_module_variable(directory, module_name):
    """ Import the variable from the desired module :
        For example we store our cat_to_num_mappings (which map categories to
        integer) in the ForProd package. In that case directory would equal ForProd
        and module_name would equal cat_to_num_mappings """
    # If directory is an absolute path (as is the case in prod)
    if os.path.isabs(directory):
        # Add directory to path
        sys.path.insert(0, directory)

        # Define module to be loaded
        module = importlib.import_module('{}'.format(module_name))
    else:
        # else if path is relative, as in creditmodel/testing
        sys.path.insert(0, os.getcwd())
        # Convert path to package format
        directory_stripped = directory.replace('/', '.')
        # Define the module
        module = importlib.import_module('{}{}'.format(directory_stripped, module_name))
        # Load module
        module_variable = getattr(module, module_name)
    return module_variable

def load_mapping_files(file_name_list, directory):
    """ load files from ForProd directory """
    files_list = []
    for file_name in file_name_list:
        module_variable = import_module_variable(directory, file_name)
        files_list.append(module_variable)
    return files_list

def transform_test(data, DataPrepTest, FeatTransTest, for_prod_dir, logger, cores, output_flag='liq_flg', prod=False):
    """ transform the test data using parameters from training sample """

    if prod:
        cores = -1
        # Take the raw data and select the prod features
        data = select_prod_features(data=data, for_prod_dir=for_prod_dir)

    # Clean data
    dataPrepTest = DataPrepTest(data=data, for_prod_dir=for_prod_dir, output_flag=output_flag, logger=logger)
    dataPrepTest.prepare_test_data()

    # File names of modules that need to be loaded
    file_name_list = ['scale_metrics_mapping', 'central_tendency_mapping', 'disc_bin_edges_mapping', 'disc_own_bin_index_mapping', 'log_odds_mapping']
    # Load the module containing transformation instructions
    scale_metrics_mapping, central_tendency_mapping, disc_bin_edges_mapping, disc_own_bin_index_mapping, log_odds_mapping = load_mapping_files(file_name_list, for_prod_dir)

    featTransTest = FeatTransTest(data=dataPrepTest._data, for_prod_dir=for_prod_dir, prod=prod, output_flag=output_flag, logger=logger,\
            scale_metrics_mapping=scale_metrics_mapping, disc_bin_edges_mapping=disc_bin_edges_mapping, central_tendency_mapping=central_tendency_mapping,\
            disc_own_bin_index_mapping=disc_own_bin_index_mapping, log_odds_mapping=log_odds_mapping, cores=cores)
    featTransTest.transform_scale_test_set()
    if prod:
        return featTransTest._data

def select_prod_features(data, for_prod_dir):
    """ takes in a dataframe and returns a dataframe with columns that are in prod features """

    # Load the prod features from the ForProd directory
    prod_features = import_module_variable(for_prod_dir, 'prod_features')['prod_features']
    # Remove the postfixes that are attached to each feature e.g. tradeCreditorsToTotalAssetsRatio_disc_logOR_stand
    # would become tradeCreditorsToTotalAssetsRatio so that it can be selected from raw data
    prod_features_clean = [remove_postfix(feature) for feature in prod_features]
    identifiers = ['company_id', 'liq_flg']
    return data[identifiers + prod_features_clean]

def remove_postfix(feature_string):
    """ takes in a string and replaces post fixes with nothing """
    return feature_string.replace('_stand', '').replace('_logOR', '').replace('_disc', '').replace('_cat', '').replace('_fit', '')



# Functions for modelling (model pre analysis included)

def write_to_python_file(file_object, file_name, directory):
    ''' writes file_object to a variable called file_name within a python file called file_name in the directory provided '''
    if file_name == 'disc_bin_edges_mapping' or file_name == 'transformations_to_apply':
        # for disc_bin_edges_mapping there will be some inf values which will need to be imported
        with open('{}{}.py'.format(directory, file_name), 'w') as outfile:
            outfile.write('from numpy import inf\n{} = {}'.format(file_name, file_object))

    else:
        with open('{}{}.py'.format(directory, file_name), 'w') as outfile:
            outfile.write('{} = {}'.format(file_name, file_object))

def compute_dataset_gini(classifier, x_data, y_data):
    """ return gini coefficient for whole dataset using a given classifier """
    from sklearn import metrics
    y_score_tr = classifier.predict_proba(x_data)
    fpr, tpr, _ = metrics.roc_curve(y_data, y_score_tr[:, 1])
    roc_auc_tr = metrics.auc(fpr, tpr)
    gini = 2 * roc_auc_tr -1
    return gini

def create_model_dataframe(clf, X_train):
    """ Creates a dataframe using the classifier that contains the different features and their coefficients """
    import pandas as pd
    coefficients = clf.coef_[0]
    features = X_train.columns.to_list()
    model_dataframe = pd.DataFrame({'feature': features, 'coefficient': coefficients})
    model_dataframe['absolute_coeff'] = abs(model_dataframe['coefficient'])
    model_dataframe['pct'] = (model_dataframe['absolute_coeff']/sum(model_dataframe['absolute_coeff']))*100
    model_dataframe.drop(columns=['absolute_coeff'], inplace=True)
    model_dataframe.sort_values('pct', ascending=False, inplace=True)
    return model_dataframe

def prep_train_and_test_set(training_sample, test_sample, output_flag, removals=[]):
    """ Preps train and test set to be used for modelling """
    train_set = training_sample.copy(deep=True)
    test_set = test_sample.copy(deep=True)
    X_train = train_set.drop(columns=[output_flag, 'company_id']+removals)
    X_test = test_set.drop(columns=[output_flag, 'company_id']+removals)
    y_train = train_set[[output_flag]]
    y_test = test_set[[output_flag]]
    return X_train, X_test, y_train, y_test
