"""
Object containing methods related to single self.feature analysis
"""

# Libraries required for self.featureTransTest #
################################################
from functools import reduce

################################################
import pandas as pd
#pylint: disable=import-error
from joblib import Parallel, delayed
from numpy import inf

from .transform_utils import import_module_variable

##############################################################################################################
# self.featureTransTest class including all functions required for self.features transformation for test set #
##############################################################################################################

class FeatureTransTest:
    """ class FeatureTransTest to be used for feature transformation as well as visualization """
    def __init__(self, data, for_prod_dir, output_flag, cores, logger, prod=False, disc_bin_edges_mapping=None, scale_metrics_mapping=None, log_odds_mapping=None, central_tendency_mapping=None, disc_own_bin_index_mapping=None):
        self.prod = prod
        self.logger = logger
        self._data = data
        self.for_prod_dir = for_prod_dir
        self.output_flag = output_flag
        self.disc_bin_edges_mapping = disc_bin_edges_mapping
        self.log_odds_mapping = log_odds_mapping
        self.scale_metrics_mapping = scale_metrics_mapping
        self.central_tendency_mapping = central_tendency_mapping
        self.disc_own_bin_index_mapping = disc_own_bin_index_mapping
        self.cores = cores
        self.logger.info('FeatTran : Reading transformations to apply to each feature from transformations_to_apply.py')
        # Load the dictionary containing which transformation to apply for each feature
        self.trans_to_apply = import_module_variable(self.for_prod_dir, 'transformations_to_apply')

    def transform_scale_test_set(self):
        """ Apply transformations and scaling in parallel to the whole test set """
        # Load the features to transform
        features_to_transform = [col for col in self.trans_to_apply if col in list(self._data.columns)]
        # Transform features in parallel
        feature_dataframe_list = Parallel(backend='multiprocessing', n_jobs=self.cores)(delayed(self.transform_and_scale_test_set_feature)(col) for col in features_to_transform)
        # Merge data transformed companies back together
        self._data = reduce(lambda x, y: pd.merge(x, y, how='inner', on=['company_id', self.output_flag]), feature_dataframe_list)
        if not self.prod:
            self.logger.info('FeatTran : Writing transformed data to data_sandbox/7_TransformTest.csv')
            self._data.to_csv('data_sandbox/7_TransformTest.csv', index=False, header=True)

    def transform_and_scale_test_set_feature(self, feature):
        """ Apply transformation and scaling to selected feature based on the transformation and  mapping files """
        self.logger.info('FeatTran : Transforming feature --> {}'.format(feature))

        # Grab the feature for all the companies so that it can be transformed
        feature_df = self._data.loc[:, [self.output_flag, 'company_id', feature]]
        # If lengths don't match
        if len(feature_df) != len(feature_df.company_id.unique()):
            raise Exception('Company id\'s are not unique, identify duplicates and remove')
        feature_df[feature] = feature_df[feature].astype(float)

        # Own bins are bins that we create during discretisation of data into bins
        # This allows us to assign a particular value, exclusively nan for now, it's
        # own default rate
        own_bins = self.trans_to_apply[feature]['discretize']['own_bins']
        if 'nan' not in own_bins:
            self.logger.info('...........Replacing missing values')
            # Replace nans with central tendency (median/mean)
            feature_df = self.replace_missing_with_train_central_tendency(feature_df, feature)
        # Check if fitting
        if self.trans_to_apply[feature]['fit']['apply']:
            self.logger.info('...........Fit')
            # Rename feature
            feature_df.rename(columns={feature:"{}_fit".format(feature)}, inplace=True)
            # Replace with log odds mapping
            feature_df = self.transform_test_log_odds(feature_df, feature + '_fit')
            # Standardise the feature
            feature_df = self.scale_test_feature(feature_df, feature + '_fit_logOR')
        # Check if discretising
        elif self.trans_to_apply[feature]['discretize']['apply']:
            self.logger.info('...........Discretize')
            # Discretize
            feature_df = self.discretize_using_train_bins(feature_df, feature, own_bins)
            # Replace bin value with log odds value of that bin
            feature_df = self.transform_test_log_odds(feature_df, feature + '_disc')
            # Standardise
            feature_df = self.scale_test_feature(feature_df, feature + '_disc_logOR')
        else:
            feature_df = self.transform_test_log_odds(feature_df, feature)
            feature_df = self.scale_test_feature(feature_df, feature + '_logOR')
        return feature_df

    def replace_missing_with_train_central_tendency(self, dataframe, feature):
        """ replace missing with mean, median, mode """
        med = self.central_tendency_mapping[feature]
        dataframe[feature].fillna(med, inplace=True)
        return dataframe

    def discretize_using_train_bins(self, dataframe, feature, own_bins):
        ''' applies discretization methods to the test set '''
        # Identify minimum bucket value. For example, if we have buckets 1-3,3-5,5-7 then
        # the min_ will be 1. This ensures all values are bucketed
        min_ = min(self.disc_bin_edges_mapping[feature])
        # Push all values below minimum value to that value
        min_mask = (dataframe[feature] < min_) & (~dataframe[feature].isin(own_bins))
        dataframe.loc[min_mask, feature] = min_
        # Repeat the process for the max
        max_ = max(self.disc_bin_edges_mapping[feature])
        max_mask = (dataframe[feature] > max_) & (~dataframe[feature].isin(own_bins))
        dataframe.loc[max_mask, feature] = max_
        # Discretise values into bins
        dataframe['{}_disc'.format(feature)] = pd.cut(dataframe[feature], self.disc_bin_edges_mapping[feature], labels=False, include_lowest=True)
        # If we created our own bins (exclusively nan), then replace those values with their bucket value
        if own_bins:
            bin_index = self.disc_own_bin_index_mapping[feature]
            for i, val in zip(bin_index, own_bins):
                if val == 'nan':
                    dataframe['{}_disc'.format(feature)].where(dataframe[feature].notna(), i, inplace=True)
                    dataframe['{}_disc'.format(feature)] = dataframe['{}_disc'.format(feature)].astype('float64')
                else:
                    dataframe['{}_disc'.format(feature)].where(dataframe[feature] != val, i, inplace=True)
        dataframe.drop(feature, axis=1, inplace=True)
        return dataframe

    def transform_test_log_odds(self, dataframe, feature):
        ''' Transform feature based on mappings from the train set
            This will replace a feature with its log odds mapping '''
        self.logger.info('FeatTran : Transforming feature to log odds --> {}'.format(feature))

        #Creating mapping for any previously unmapped values
        # Mapping tuples contains the log odds for each bin so that we can take the feature
        # for a particular company, assign it to a bin, and replace it's value with the
        # log odds for that bin
        mapping_tuples = self.log_odds_mapping[feature]
        # Force the column to be type float
        dataframe[feature] = dataframe[feature].astype('float64')
        # This list will be used to keep track of the possible log odds values
        train_set_value_list = []
        # Here we loop over the bin:log_odds dictionary and take the bin number
        for tup in mapping_tuples:
            train_set_value_list.append(tup[0])
        # Sometimes the value for the feature is not covered by the bins. In that case we find the closest
        # bin and replace it with that
        for value in dataframe[feature]:
            if value not in train_set_value_list:
                closest_value = min(train_set_value_list, key=lambda x: abs(x-value))
                dataframe[feature].replace(value, closest_value, inplace=True)

        # Creating list of indexes to replace values with
        index_mapping_tuples = []
        # get the indexes of all the values that will be replaced for each bin:log_odds_pair
        for tup in mapping_tuples:
            index_list = dataframe[feature].loc[(dataframe[feature] == tup[0])].index.tolist()
            index_tup = (index_list, tup[1])
            index_mapping_tuples.append(index_tup)

        # Replace values with mapping
        for tup in index_mapping_tuples:
            dataframe.at[tup[0], feature] = tup[1]

        dataframe.rename(columns={feature:"{}_logOR".format(feature)}, inplace=True)
        return dataframe

    def scale_test_feature(self, dataframe, feature):
        ''' Scales feature based on mappings from the train set '''
        self.logger.info('FeatTran : Scaling feature --> {}'.format(feature))
        # Ensure they type is float
        dataframe[feature] = dataframe[feature].astype(float)
        # Read the mean for the feature
        sc_mean = self.scale_metrics_mapping[feature][0]
        # Read the standard deviation for the flter
        sigma = self.scale_metrics_mapping[feature][1]
        # Standardise
        dataframe['{}_stand'.format(feature)] = (dataframe[feature] - sc_mean) / sigma
        # Drop unstandardised feature
        dataframe.drop(feature, axis=1, inplace=True)
        return dataframe
