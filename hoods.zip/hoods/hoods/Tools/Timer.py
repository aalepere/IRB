''' Timer Class which alllows timing seperate events in the application '''
import datetime

class Timer:
    ''' Timer for tracker different events by name '''
    def __init__(self, logger):
        ''' timer_dict will contain the start time of an individual timer '''
        self.timer_dict = {}
        self.logger = logger

    def initiate_timer(self, name):
        ''' initiate_timer takes a name and assigns teh time at which it is called '''
        self.timer_dict[name] = datetime.datetime.now()

    def finish_timer(self, name, message):
        ''' finish_timer takes a name of a previously
            initiated timer and prints the elapsed time with a message '''
        if name not in self.timer_dict:
            self.logger.critical('{} is not an initiated timer'.format(name))
        else:
            elapsed_time = str(datetime.datetime.now() - self.timer_dict[name])
            self.logger.info('TimeElaps : {} took {}'.format(message, elapsed_time))
