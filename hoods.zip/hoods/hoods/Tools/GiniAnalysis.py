"""
Description: Compute the Gini coefficient for all the selected features
"""

#############
# Libraries #
#############
import pandas as pd
from .research_utils import compute_gini

###################################################################################
# GiniAnalysis class including all functions required for predictive power review #
###################################################################################

class GiniAnalysis:
    """ GiniAnalysis class containing methods related to the analysis """

    def __init__(self, data, output_flag, logger):
        """ data {dataframe}, output_flag {string}"""
        self._data = data
        self.output_flag = output_flag
        self.logger = logger

    def retrieve_gini_analysis(self):
        """ writes a csv called 2_features_to_remove.csv containing all features alongside their gini coefficient """
        self.logger.info('GiniAnal : Starting retrieve gini analysis dataframe')
        gini_scores = []
        for c in self._data.columns:
            # for each of the columns calculate the gini
            g = compute_gini(self._data[self._data[c].notna()], c, self.output_flag)
            gini_scores.append([c, g])
        df = pd.DataFrame(gini_scores, columns=['column_name', 'gini_coeff'])
        df['gini_coeff_abs'] = abs(df['gini_coeff'])
        self.logger.info('GiniAnal : Finished calculating Gini scores for features')
        df = df.sort_values('gini_coeff_abs', ascending=False)
        df = df.reset_index(drop=True)
        # creates column that will be filled in by user, True means it is not involved in analysis, False means it is;
        df['to_remove'] = False
        df['reason'] = None
        df[['gini_coeff', 'gini_coeff_abs']] = df[['gini_coeff', 'gini_coeff_abs']].round(5)
        df = df[df.column_name != 'liq_flg'] # remove liq flg
        df = df[df.column_name != 'liq_res_flg'] # remove liq_res_flg
        df = df[df.column_name != 'company_id'] # remove liq_res_flg
        df.to_csv('2_features_to_remove.csv', index=True)
        self.logger.info('GiniAnal : Gini results stored in 2_features_to_remove.csv, table needs to be filled out')

    def write_filtered_dataframe(self):
        ''' writes filtered dataframe to data_sandbox '''
        self.filter_unwanted_features()
        self.logger.info('GiniAnal : Writing dataframe with selected features from 2_features_to_remove.csv to data_sandbox/3_DataTopFeatures.csv')
        self._data.to_csv('data_sandbox/3_DataTopFeatures.csv', index=False, header=True)

    def filter_unwanted_features(self):
        """ writes a dataframe filtered for columns you want to keep  """
        exclusion_list = self.read_exclusion_list()
        self.logger.info("GiniAnal : Starting keep top features")
        self.logger.info('GiniAnal : DataFrame has {} columns'.format(len(self._data.columns)))
        self.logger.info('GiniAnal : Removing {} columns'.format(len(exclusion_list)))
        for col in self._data.columns:
            if col not in ['company_id', self.output_flag]:
                if col in exclusion_list:
                    self._data.drop(col, axis=1, inplace=True)
        self.logger.info('GiniAnal : DataFrame now has {} columns'.format(len(self._data.columns)))

    def read_exclusion_list(self):
        ''' this function reads in the 2_features_to_remove.csv and returns a list of features to be excluded from the model '''
        self.logger.info('GiniAnal : Reading 2_features_to_remove; filtering features to keep and remove based on answers')
        df = pd.read_csv('2_features_to_remove.csv', index_col=0)
        exclude = []
        for i in df.values.tolist():
            if not isinstance(i[3], bool):
                self.logger.critical('{} still needs to be checked, has value {} and needs to be True (remove) or False (keep)'.format(i[0], i[3]))
            elif i[3]:
                exclude.append(i[0])
            elif not i[3]:
                pass
        self.logger.info('GiniAnal : {} features will be removed'.format(len(exclude)))
        return exclude
