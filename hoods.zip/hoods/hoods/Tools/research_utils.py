"""
Utils: Set of functions to be used accross objects
"""

################################
# Libraries required for Utils #
################################
import sys

import math
import numpy as np
import pandas as pd
from mdlp.discretization import MDLP
from numpy import inf
from pynverse import inversefunc
from scipy.optimize import curve_fit
from scipy.stats.mstats import winsorize
from sklearn import metrics
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import StandardScaler

from .Modelling.transform_utils import import_module_variable, compute_dataset_gini, write_to_python_file

#Turns off settingwithcopywarning in Pandas
pd.options.mode.chained_assignment = None

def get_logger(company_size, stream_handler_active=True):
    """ creates a logger with a file handler and stream handler
        @param company_size {string}
        @return logger with handlers set """
    import logging
    logger = logging.getLogger(__name__)
    if logger.hasHandlers():
        logger.handlers.clear()
    logger.setLevel(logging.DEBUG)
    formatter = logging.Formatter('%(asctime)s %(levelname)-8s: %(message)s', datefmt='%d/%m %H:%M')
    file_handler = logging.FileHandler('{}.log'.format(company_size))
    file_handler.setFormatter(formatter)
    logger.addHandler(file_handler)
    if stream_handler_active:
        stream_handler = logging.StreamHandler()
        stream_handler.setFormatter(formatter)
        logger.addHandler(stream_handler)
    return logger

def compute_default_rate(data, feature, output_flag):
    """ Computes default rate for a given feature, DR = number of bads / total number of companies
            @param feature {text}, output_flag {text}, self._data {data}
            @return data with additional columns called feature_DR
    """
    if '{}_DR'.format(feature) in data.columns:
        data = data.drop(['{}_DR'.format(feature)], axis=1)

    # Get the mean of default (i.e Default rate) for each distinct value
    grouping = data[[feature, output_flag]].groupby([feature], as_index=False)[output_flag].mean()
    grouping.columns = [feature, '{}_DR'.format(feature)]

    # Merge it to the main self._dataframe
    data = pd.merge(data, grouping, how='left', on=feature)

    return data

def compute_gini(data, feature, output_flag):
    """ returns gini coefficient for a given feature
    @param output_flag {text}, feature {array}
    @return gini coeffient for the feature and flag {float}"""
    fpr, tpr, _ = metrics.roc_curve(data[output_flag], data[feature])
    g = 2 * metrics.auc(fpr, tpr) - 1
    return g

def feature_distribution(data, feature):
    """ returns plot of the feature distribution
    @param feature {text}, data {dataframe}
    @return plot {plt}"""
    import matplotlib.pyplot as plt
    return plt.hist(data[feature].sort_values())

def feature_DR_rel(data, feature):
    """ returns plot of the feature relationship with DR
    @param feature {text}, output_flag {text}, data {dataframe}
    @return plot {plt}"""
    import matplotlib.pyplot as plt
    data.sort_values(by=feature, inplace=True)
    return plt.plot(data[feature], data['{}_DR'.format(feature)])

def plot_fitted_against_unfitted(data, feature, fit_fco):
    """ returns plot of the feature fitted against original feature
    @param feature {text}, fit_fco {array}, data {dataframe}
    @return plot {plt}"""
    import matplotlib.pyplot as plt
    data.sort_values(by=feature, inplace=True)
    return plt.plot(data[feature], fit_fco, 'r-', data[feature], data['{}_DR'.format(feature)], 'b-')

def plot_fitted(data, feature, fit_fco):
    """ returns plot of the feature fitted
    @param feature {text}, fit_fco {array}, data {dataframe}
    @return plot {plt}"""
    import matplotlib.pyplot as plt
    data.sort_values(by=feature, inplace=True)
    return plt.plot(data[feature], fit_fco, 'r-', label='data')

def plot_discretize(data, feature):
    """ returns plot of the feature discretized
    @param feature {text}, data {dataframe}
    @return plot {plt}"""
    import matplotlib.pyplot as plt
    return plt.plot(data.groupby(['{}_disc'.format(feature)])['{}_DR'.format(feature)].mean())


#Functions from FeatureTrans

def replace_missing_with_central_tendency(dataframe, column, rep_method):
    """ replace missing values in a dataset with mean, median, or mode
    @param dataframe {dataframe}, column {string}, rep_method {string}, logger {logger object}
    @return dataframe with NaNs filled {dataframe} key value pair of column and ct {dictionary}
    """
    try:
        if rep_method == 'median':
            ct = dataframe[column].median()
        elif rep_method == 'mode':
            ct = dataframe[column].mode()[0]
        elif rep_method == 'mean':
            ct = dataframe[column].mean()
        elif isinstance(rep_method, (float, int)):
            ct = rep_method
        else:
            sys.exit('WARNING : Must set nan_rep_method equal to mode, median, mean, an integer, or float')
        column_central_tendency = {column : ct}
        dataframe[column].fillna(ct, inplace=True)
    except KeyError as error:
        sys.exit("WARNING : Error when replacing missing values in column {} --> {}, consider adding to data_prep_column_clean.json[NonNumericCols] ".format(column, error))
    return dataframe, column_central_tendency

def remove_specific_value(dataframe, column, remove_val):
    """ Remove a specified value from the column of a dataframe.
            To be used when removing outliers
            @param dataframe {dataframe}, column {string}, remove_val {integer or float}
            @return dataframe with removed value {dataframe}
    """
    dataframe = dataframe[dataframe[column] != remove_val]
    return dataframe

def group_values_together(dataframe, column, cutoff):
    """ Group values above a cutoff point together at the cutoff point.
            To be used when grouping outliers
            @param dataframe {dataframe}, column {string}, cutoff {integer or float}
            @return dataframe with values grouped {dataframe}
    """
    dataframe.loc[:, column] = dataframe[column].apply(lambda x: cutoff if x >= cutoff else x)
    return dataframe

def winsorize_column(dataframe, column, threshold):
    """ Remove outliers from the column in the dataframe by winsorizing it according to provided threshold.
            To be used when grouping outliers from the positive and negative
            @param dataframe {dataframe}, column {string}, threshold {float}
            @return dataframe with winsorized column {dataframe}
    """
    dataframe.loc[:, column] = winsorize(dataframe[column], limits=threshold)
    return dataframe

def fit_function(dataframe, column, params, output_flag):
    """ Tries to fit a function depeding on the number of parameters provide
            @param dataframe {dataframe}, column {string}, params {integer}
            @return list of fitted parameters for the given function
    """

    dataframe = compute_default_rate(data=dataframe, feature=column, output_flag=output_flag)

    # m,t
    if params == 2:
        def fco_2(x, m, t):
            """ 2 parameters function to be fitted against default rate """
            return 1 / (1 + np.exp(m*x + t))
        dataframe.sort_values(by=column, inplace=True)
        popt, _ = curve_fit(fco_2, dataframe[column], dataframe['{}_DR'.format(column)])

    # m,t,a
    elif params == 3:
        def fco_3(x, m, t, a):
            """ 3 parameters function to be fitted against default rate """
            return a / (1 + np.exp(m*x + t))
        dataframe.sort_values(by=column, inplace=True)
        popt, _ = curve_fit(fco_3, dataframe[column], dataframe['{}_DR'.format(column)])

    # m,t,a,b
    elif params == 4:
        def fco_4(x, m, t, a, b):
            """ 4 parameters function to be fitted against default rate """
            return a / (b + np.exp(m*x + t))
        dataframe.sort_values(by=column, inplace=True)
        popt, _ = curve_fit(fco_4, dataframe[column], dataframe['{}_DR'.format(column)])

    else:
        sys.exit('WARNING : Please set params equal to 2, 3, or 4')

    return dataframe, popt

def return_fit(dataframe, column, params, output_flag):
    """ Return fitted function as an array for plotting"""

    dataframe, popt = fit_function(dataframe=dataframe, column=column, params=params, output_flag=output_flag)

    if len(popt) == 2:
        def fco_fit2(x, m, t):
            """ return the 2 parameters function that has been fitted """
            return 1 / (1 + np.exp(m*x + t))
        fit_fco = fco_fit2(dataframe[column], *popt)

    if len(popt) == 3:
        def fco_fit3(x, m, t, a):
            """ return the 3 parameters function that has been fitted """
            return a / (1 + np.exp(m*x + t))
        fit_fco = fco_fit3(dataframe[column], *popt)

    if len(popt) == 4:
        def fco_fit4(x, m, t, a, b):
            """ return the 4 parameters function that has been fitted """
            return a / (b + np.exp(m*x + t))
        fit_fco = fco_fit4(dataframe[column], *popt)

    return fit_fco

def inverse_and_transform(dataframe, column, params, output_flag):
    """ Inverse the fitted function and retrieve a transform feature call feature_fit
        @param self.popt {list}, self.params {text}, self._data {self._dataframe}
        @return self._data with new column called feature_fit
    """

    dataframe, popt = fit_function(dataframe=dataframe, column=column, params=params, output_flag=output_flag)

    # As we have an exponential in the fitted fco we need to replace 0 to 0.0001
    def inv_fco_clean(row):
        """ inverse the original function an default 0 to 0.00001 """
        if not row:
            return inv_fco(0.0001)
        else:
            return inv_fco(row)

    if len(popt) == 2:
        # Define a function based on the based fit (see fit_function)
        fco = (lambda x: 1 / (1 + np.exp(popt[0] * x + popt[1])))

    if len(popt) == 3:
        # Define a function based on the based fit (see fit_function)
        fco = (lambda x: popt[2] / (1 + np.exp(popt[0] * x + popt[1])))

    if len(popt) == 4:
        # Define a function based on the based fit (see fit_function)
        fco = (lambda x: popt[2] / (popt[3] + np.exp(popt[0] * x + popt[1])))

    # Take the inverse of the function
    inv_fco = inversefunc(fco)

    # Create a new columns call column_fit
    dataframe['{}_fit'.format(column)] = dataframe['{}_DR'.format(column)].apply(lambda y: inv_fco_clean(y))
    dataframe.drop(columns=['{}_DR'.format(column), column], axis=1, inplace=True)

    return dataframe

def discretize_column(dataframe, column, output_flag, custom_bin_edges, own_bins, how, seed, n, method, range_, weights, filtered_data, transform_flag=False):
    """ combines all discretization fcos """
    if custom_bin_edges:
        bin_edges = custom_bin_edges
    else:
        if how == 'MDLP':
            bin_edges = discretize_mdlp(dataframe, column, seed, output_flag, own_bins)
        elif how == 'quantile':
            bin_edges = discretize_quantile(dataframe, column, n, own_bins)
        elif how == 'numpy':
            bin_edges = discretize_numpy(range_, weights, dataframe, column, method, own_bins)
        else:
            sys.exit("WARNING : 'how' must be equal to MDLP, quantile, or numpy")

    bin_edges[0] = -inf
    bin_edges[-1] = inf
    column_bin_edges = {column : bin_edges}
    dataframe.loc[:, '{}_disc'.format(column)] = pd.cut(dataframe[column], bin_edges, labels=False, include_lowest=True)

    if transform_flag and own_bins:
        dataframe = dataframe.append(filtered_data, sort=True)
        dataframe, column_own_bin_index_list = create_own_bins(dataframe, column, own_bins)
        dataframe.drop(column, axis=1, inplace=True)
        return dataframe, column_bin_edges, column_own_bin_index_list

    elif transform_flag and not own_bins:
        dataframe.drop(column, axis=1, inplace=True)
        return dataframe, column_bin_edges

    elif not transform_flag and own_bins and filtered_data is not None:
        dataframe = dataframe.append(filtered_data, sort=True)
        dataframe, column_own_bin_index_list = create_own_bins(dataframe, column, own_bins)
        return dataframe, column_bin_edges[column], column_own_bin_index_list[column]

    else:
        return dataframe, column_bin_edges[column]

def discretize_mdlp(dataframe, column, seed, output_flag, own_bins):
    """ Discretize a column using the MDLP library
            @param dataframe {dataframe}, column {string}, seed {integer}, output_flag {string}, own_bins {list}
            @return list of edges to create bins for the given column {list}
    """
    # Generate random seed to be able to reproduce transformation later
    transformer = MDLP(random_state=seed)

    # _data is to be sorted to be able to use MDLP
    dataframe.sort_values(by=column, inplace=True)

    # Create own bins mask
    bins_mask = ~dataframe[column].isin(own_bins)

    # Create a new variable column_disc
    s_transformed = transformer.fit_transform(dataframe.loc[bins_mask, column].values.reshape(-1, 1), dataframe.loc[bins_mask, output_flag])

    # Retrieve the edges to the generated bins
    column_bin = set(transformer.cat2intervals(s_transformed, 0))
    bins_list = sorted(list(column_bin))
    bin_edges = []
    for val in bins_list:
        bin_edges.append(val[0])
    bin_edges.append(inf)

    return bin_edges

def discretize_quantile(dataframe, column, n, own_bins):
    """ Discretize a column using n equal splits
            @param dataframe {dataframe}, column {string}, n {integer}, own_bins {list}
            @return list of edges to create bins for the given column {list}
    """
    _, bin_edges = pd.qcut(dataframe.loc[~dataframe[column].isin(own_bins), column], n, retbins=True, duplicates='drop')
    return list(bin_edges)

def discretize_numpy(range_, weights, dataframe, column, method, own_bins):
    """ Discretize a column using numpy method
            @param range_ {}, weights {}, dataframe {dataframe}, column {string}, method {string}, own_bins {list}
            @return list of edges to create bins for the given column {list}
    """
    if range_ == "None":
        range_ = eval(range_)
    if weights == "None":
        weights = eval(weights)
    bin_edges = np.histogram_bin_edges(dataframe.loc[~dataframe[column].isin(own_bins), column], bins=method, range=range_, weights=weights)
    return list(bin_edges)



def create_own_bins(dataframe, column, own_bins):
    ''' creates bins specified by the user '''
    new_bin = dataframe['{}_disc'.format(column)].max() + 1
    new_bin_index_list = []
    for val in own_bins:
        if val == 'nan':
            dataframe['{}_disc'.format(column)].where(dataframe[column].notna(), new_bin, inplace=True)
        else:
            dataframe['{}_disc'.format(column)].where(dataframe[column] != val, new_bin, inplace=True)
        new_bin_index_list.append(new_bin)
        new_bin += 1
    column_own_bin_index_list = {column : new_bin_index_list}
    return dataframe, column_own_bin_index_list


def transform_to_log_odds(dataframe, column, output_flag):
    """
        Transform dataframe column to its log odds equivalent to ensure each column has the same score currency
         - Takes the default rate of a column
         - Replaces any extreme values (1's and 0's)
         - Converts the default rate to its log odds format
         - Formula: log( DR / (1-DR) )
         - Saves all the different possible mappings from the original value to the log odds value
         - Renames the column with _log and drops original column
         - Returns the dataframe and set of mapping tuples
    """
    dataframe = compute_default_rate(data=dataframe, feature=column, output_flag=output_flag)
    dataframe['{}_DR'.format(column)].replace(0, 0.000000000001, inplace=True)
    dataframe['{}_DR'.format(column)].replace(1, 0.999999999999, inplace=True)
    dataframe['{}_DR'.format(column)] = np.log(dataframe['{}_DR'.format(column)]/(1-dataframe['{}_DR'.format(column)]))
    mapping_tuples = set(zip(dataframe[column], dataframe['{}_DR'.format(column)]))
    dataframe.rename(columns={'{}_DR'.format(column): '{}_logOR'.format(column)}, inplace=True)
    dataframe.drop(column, axis=1, inplace=True)
    return dataframe, {column: mapping_tuples}


def scale_feature(dataframe, column):
    """
        Custom standard scaler for a column in a dataframe
         - Ensures the column is a float
         - Calculates the mean and standard deviation using sklearn
         - The mean and standard deviation are deducted from every value in the column
         - The column is renamed with _stand added to the end and the original column is dropped
         - Returns the dataframe (with modified column), column mean, column sigma
    """
    dataframe[column] = dataframe[column].astype(float)
    standard_scaler = StandardScaler(copy=True, with_mean=True, with_std=True)
    standard_scaler.fit(dataframe[column].to_frame())
    sc_mean = standard_scaler.mean_[0]
    sigma = math.sqrt(standard_scaler.var_[0])
    dataframe['{}_stand'.format(column)] = standard_scaler.transform(dataframe[column].to_frame())
    dataframe.drop(column, axis=1, inplace=True)
    scale_metrics = [sc_mean, sigma]
    return dataframe, {column: scale_metrics}


def full_viz(data, output_flag, for_prod_dir, feature, bin_values, nan_rep_method, remove_value, remove_val,
             group_values, cutoff, winsorize, threshold, fit, params, discretize, how, method, weights,
             range_, seed, n, new_edges, write_params):
    """ provide a full visual analysis of a feature, different options can be selected: fit, winsorize or MDLP
    @param
    data {dataframe}, output_flag {string}, for_prod_dir {string}, feature {string}, bin_values {list},
    nan_rep_method {string}, remove_value {boolean}, remove_val {integer}, group_values {boolean}, cutoff {integer},
    winsorize {boolean}, threshold {integer}, fit {boolean}, params {integer}, discretize {boolean}, how {string},
    method {string}, seed {integer}, n {integer}, new_edges {list}, range_ {float}, weights {array}, write_params {boolean},
    @return plots {plt}"""
    import matplotlib.pyplot as plt

    data = data.copy(deep=True)

    dr_nan = data[data[feature].isna()]['liq_flg'].sum()
    sum_nan = data[feature].isna().sum()
    if sum_nan > 0:
        print('Default rate of companies with NaNs = {}'.format(dr_nan/sum_nan))
    else:
        print('No companies with NaN!')
    print('Total number of companies with NaN = {}\n'.format(sum_nan))

    # nan rep method stats
    if nan_rep_method == 'median':
        ct = data[feature].median()
    elif nan_rep_method == 'mode':
        ct = data[feature].mode()[0]
    elif nan_rep_method == 'mean':
        ct = data[feature].mean()
    elif isinstance(nan_rep_method, (float, int)):
        ct = nan_rep_method
    else:
        sys.exit('WARNING : Must set nan_rep_method equal to mode, median, mean, an integer, or float')
    dr_ct = data[data[feature] == ct]['liq_flg'].sum()
    sum_ct = (data[feature] == ct).sum()
    print(f'{nan_rep_method} value = {ct}')
    if sum_ct > 0:
        print(f'Default rate of companies with {nan_rep_method} value = {dr_ct/sum_ct}')
    else:
        print(f'No companies with {nan_rep_method} value!')
    print(f'Total number of companies with {nan_rep_method} = {sum_ct}\n')

    dr_zero = data.loc[(data[feature] == 0), 'liq_flg'].sum()
    sum_zero = (data[feature] == 0).sum()
    print('Total number of companies with 0: {}'.format(sum_zero))
    print('Default rate of companies with 0: {}\n'.format(dr_zero/sum_zero))
    print('Total number of companies: {}\n'.format(len(data)))

    # Adjustments based on data visualisation

    if bin_values and not discretize:
        sys.exit('WARNING : discretize must be set to true if you are going to bin values')

    if fit and discretize:
        sys.exit('WARNING : cannot fit and discretize at the same time')

    if bin_values:
        # Take the values out of dataset and make their own bin
        filtered_data = data[data[feature].isin(bin_values)]
        data = data[~data[feature].isin(bin_values)]

    if 'nan' not in bin_values:
        # if nan hasn't been replaced already, then replace the nans with the middle value of that column
        data, _ = replace_missing_with_central_tendency(dataframe=data, column=feature, rep_method=nan_rep_method)
        replacement_apply = True
    else:
        replacement_apply = False

    if remove_value:
        # after visualising, you might want to remove some outliers using this
        bads_pre_remove = (data['liq_flg'] == 1).sum()
        data = remove_specific_value(dataframe=data, column=feature, remove_val=remove_val)
        bads_removed = bads_pre_remove - (data['liq_flg'] == 1).sum()
        print(f'Number of bads removed = {bads_removed}')

    if group_values:
        # takes a specific value, and everything ABOVE that value is grouped into it
        data = group_values_together(dataframe=data, column=feature, cutoff=cutoff)

    if winsorize:
        # brings in outliers from both ends to nearest buckets
        data = winsorize_column(dataframe=data, column=feature, threshold=threshold)

    if fit:
        # fit function data to smooth out noise
        fit_fco = return_fit(dataframe=data, column=feature, params=params, output_flag=output_flag)

    # compute the new gini
    current_gini = compute_gini(data=data, feature=feature, output_flag=output_flag)

    if discretize:
        if bin_values:
            bins_removed_data = data.copy(deep=True)
            bins_added_data, edges, own_bin_index_list = discretize_column(dataframe=bins_removed_data, column=feature, output_flag=output_flag, custom_bin_edges=new_edges,\
                    own_bins=bin_values, how=how, seed=seed, n=n, method=method, range_=range_, weights=weights, filtered_data=filtered_data)

        data, edges = discretize_column(dataframe=data, column=feature, output_flag=output_flag, custom_bin_edges=new_edges,\
                own_bins=bin_values, how=how, seed=seed, n=n, method=method, range_=range_, weights=weights, filtered_data=None)


        # when creating some new edges, this makes sure that all values can be grouped into bins
        if new_edges and data['{}_disc'.format(feature)].isna().sum() > 0:
            sys.exit('WARNING : New edges generated do not cover whole dataset, try expanding maximum and minimum')
        current_gini = compute_gini(data=data, feature=feature + '_disc', output_flag=output_flag)

    print('Current gini: {}\n'.format(current_gini))
    data = compute_default_rate(data=data, feature=feature, output_flag=output_flag)

    # Plot distribution
    plt.figure(figsize=(15, 15))
    plt.subplot(4, 1, 1)
    feature_distribution(data=data, feature=feature)
    plt.title('%s Analysis' % feature)
    plt.ylabel('# of companies')
    plt.xlabel(feature)

    # Plot relationship to DR
    plt.subplot(4, 1, 2)
    feature_DR_rel(data=data, feature=feature)
    plt.ylabel('Default rate')
    plt.xlabel(feature)

    # Plot fit
    if fit:
        plt.subplot(4, 1, 3)
        plot_fitted_against_unfitted(data=data, feature=feature, fit_fco=fit_fco)
        plt.ylabel('Default rate')
        plt.xlabel(feature)
        plt.subplot(4, 1, 4)
        plot_fitted(data=data, feature=feature, fit_fco=fit_fco)
        plt.ylabel('Default rate')
        plt.xlabel(feature)

    # Plot discretize
    if discretize:
        plt.subplot(4, 1, 3)
        plot_discretize(data=data, feature=feature)
        plt.ylabel('Default rate')
        plt.xlabel('Discretized {}'.format(feature))
        bins_or_edges = edges
        labels = []
        for i, val in enumerate(bins_or_edges):
            if i+1 < len(bins_or_edges):
                n_bool = ((data[feature] <= bins_or_edges[i+1]) & (data[feature] > val)).sum()
                labels.append(('{}\nBin rng\n({},\n{}]\n n={}'.format(i, round(val, 3), round(bins_or_edges[i+1], 3), n_bool)))
        print('Edges generated: {}\n'.format(edges))
        plt.xticks(range(len(edges)), labels)


    # Add whether feature will become positive or negative
    if discretize:
        if bin_values:
            bins_added_data, log_odds = transform_to_log_odds(dataframe=bins_added_data, column=feature + '_disc', output_flag=output_flag)
            feature_name_mod = feature + '_disc_logOR'
            _, scale_metrics = scale_feature(dataframe=bins_added_data, column=feature + '_disc_logOR')
        else:
            data, log_odds = transform_to_log_odds(dataframe=data, column=feature + '_disc', output_flag=output_flag)
            feature_name_mod = feature + '_disc_logOR'
            _, scale_metrics = scale_feature(dataframe=data, column=feature + '_disc_logOR')
    else:
        data, log_odds = transform_to_log_odds(dataframe=data, column=feature, output_flag=output_flag)
        feature_name_mod = feature + '_logOR'
        _, scale_metrics = scale_feature(dataframe=data, column=feature + '_logOR')
    mean = scale_metrics[feature_name_mod][0]
    sd = scale_metrics[feature_name_mod][1]
    scaled_mapping = {}
    for k, v in log_odds[feature_name_mod[:-6]]:
        scaled_mapping[k] = (v-mean)/sd
    mapping_df = pd.DataFrame(scaled_mapping, [0]).T.sort_index()
    mapping_df.rename(columns={0: 'transformed_value'}, inplace=True)
    mapping_df.index = mapping_df.index.rename('value')
    print(mapping_df)
    if bin_values:
        own_bins_dict = dict(zip(own_bin_index_list, bin_values))
        print(f"Own bins: {own_bins_dict}")


    # Write transformations to be applied to each feature to a file
    d = import_module_variable(for_prod_dir, 'transformations_to_apply')
    if write_params:
        el = {
            feature: {
                'replace_nans': {
                    'apply': replacement_apply,
                    'rep_method': nan_rep_method
                },
                'remove': {
                    'apply': remove_value,
                    'remove_val':remove_val
                },
                'group':{
                    'apply': group_values,
                    'cutoff': cutoff
                },
                'winsorize': {
                    'apply': winsorize,
                    'threshold': threshold
                },
                'fit': {
                    'apply': fit,
                    'params': params
                },
                'discretize': {
                    'apply': discretize,
                    'how': how,
                    'seed': seed,
                    'n': n,
                    'method': method,
                    'range': range_,
                    'weights': weights,
                    'own_bins': bin_values,
                    'new_edges': new_edges
                }
            }
        }
        d.update(el)
    elif write_params == False:
        if feature in d:
            _ = d.pop(feature, None)
    write_to_python_file(d, 'transformations_to_apply', for_prod_dir)

# FUNCTIONS FROM MODEL PRE ANALYSIS

def select_prod_features(dataset, features_to_remove, output_flag):
    """
        Selects features to go to prod based on features to be removed from the model
        features_to_remove should be a list containing features in the dataset that are to be removed
    """
    removals = features_to_remove + [output_flag, 'company_id']
    prod_features_list = [feature for feature in dataset.columns if feature not in removals]
    return prod_features_list

def write_prod_features(prod_features, for_prod_dir):
    """
        Write prod features to for prod directory
        prod_features should be in list format
    """
    prod_features_dict = {'prod_features': prod_features}
    write_to_python_file(prod_features_dict, 'prod_features', for_prod_dir)

def print_gini_scores(classifier, X_train, y_train, X_test, y_test):
    """ Prints classifier and gini scores """
    print('Gini train score:       {}'.format(compute_dataset_gini(classifier, X_train, y_train)))
    print('Gini test score:        {}'.format(compute_dataset_gini(classifier, X_test, y_test)))

def parameter_tuning(penalty, C_train, X_train, y_train, X_test, y_test):
    """ Tuning penalty and C parameters if using regular regression """
    gini_train = []
    gini_test = []
    for i in C_train:
        cls = LogisticRegression(C=i, penalty=penalty)
        cls.fit(X_train, y_train)
        gini_train.append(compute_dataset_gini(cls, X_train, y_train))
        gini_test.append(compute_dataset_gini(cls, X_test, y_test))

    gini_df = pd.DataFrame({'C': C_train, 'gini_train': gini_train, 'gini_test': gini_test})
    gini_df['diff'] = gini_df['gini_train'] - gini_df['gini_test']
    return gini_df

def display_correlation_matrix(dataset, removals, output_flag):
    """ Displays a correlation matrix heatmap """
    import matplotlib.pyplot as plt
    import seaborn as sns
    data = dataset.drop(columns=['company_id', output_flag] + removals)
    corr = data.corr()
    plt.figure(figsize=(30, 20))
    sns.heatmap(corr, xticklabels=corr.columns, yticklabels=corr.columns, annot=True)
    plt.show()

def display_highest_correlated(dataset, removals, output_flag):
    """ Displays the top 5 highest correlated features """
    data = dataset.drop(columns=['company_id', output_flag] + removals)
    corr = data.corr()
    corr.replace(1.0, 0.0, inplace=True)
    corr = abs(corr)
    index = []
    column = []
    largest = []
    for i in corr:
        index += corr.nlargest(10, i)[i].index.tolist()
        largest += corr.nlargest(10, i)[i].tolist()
        column += [i]*10
    df = pd.DataFrame({'index': index, 'column': column, 'value': largest})
    return df.nlargest(10, 'value').reset_index(drop=True).iloc[[0, 2, 4, 6, 8]]

def create_pvalue_dataframe(X_train, y_train):
    """ Calculate coefficient dataframe with p-values """
    from .LogisticRegressionWithPValues import LogisticRegressionWithPValues
    cls = LogisticRegressionWithPValues()
    cls.fit(X_train, y_train)

    pvalue_dataframe = pd.DataFrame({'feature': X_train.columns.tolist(), 'coeff': cls.model.coef_.tolist()[0],
                                     'p_values': [round(p_val, 4) for p_val in cls.p_values]})
    pvalue_dataframe['pct'] = (abs(pvalue_dataframe['coeff']) / abs(pvalue_dataframe['coeff']).sum()) * 100
    pvalue_dataframe.sort_values('pct', ascending=False, inplace=True)
    return pvalue_dataframe[['feature', 'coeff', 'p_values', 'pct']]

def remove_features_by_p_value(X_train, y_train, p_val_list):
    """ Remove features based on their p-value """
    removals = []
    for p_val_threshold in p_val_list:
        X_data = X_train.drop(removals, axis=1)
        print(f'Removing features with p_value > {p_val_threshold}')
        print(f'{len(removals)} features in removals')
        pvalue_dataframe = create_pvalue_dataframe(X_data, y_train)
        removals.extend(pvalue_dataframe[pvalue_dataframe.p_values > p_val_threshold].feature.values.tolist())
    return removals

# FUNCTIONS FROM CALIBRATION AND DISTRIBUTION

def score_and_order_data(_data, output_flag, company_size):
    """ Gets credit scores for data set and returns them in ascending order alongwith their output flag and proba """
    creditModel = load_credit_model(company_size)
    score_df = pd.DataFrame()
    score_df[output_flag] = _data[output_flag]
    X_data = _data.drop(columns=['company_id', output_flag])
    score_df['proba'] = creditModel.predict_proba(X_data)[:, 1]
    score_df['score'] = np.log(score_df['proba'] / (1 - score_df['proba']))
    score_df.sort_values(by='score', ascending=True, inplace=True)
    score_df.reset_index(drop=True, inplace=True)
    return score_df

def load_credit_model(company_size):
    """ Loads the credit model for a given company size """
    import pickle
    from .Modelling import LogisticRegressionWithPenalties
    with open('CreditModel_{}.p'.format(company_size), 'rb') as infile:
        creditModel = pickle.load(infile)
    return creditModel
