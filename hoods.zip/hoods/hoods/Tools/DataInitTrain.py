"""
Description: List of all functions required for Data Initiation for Single feature analysis
"""
###########################################
# Libraries required for Data Initiation #
###########################################
import warnings
import os
import sys
import json
from sklearn import model_selection
import pandas as pd
import numpy as np

#############################################################################
# DataInitTrain class including all functions required for data preparation #
#############################################################################

class DataInitTrain:
    ''' Takes financial and non financials dataset, filters the data and split in train and test sets '''
    def __init__(self, data_path, company_size, logger, train_size=None):
        self._data = pd.read_csv(data_path)
        self.company_size = company_size
        self.logger = logger
        self.logger.warning("DataInit : Not specifying data types for input files, memory inefficient")
        self.logger.info("DataInit : Reading dataframe from {}".format(data_path))
        self.logger.info("DataInit : Dataframe has {} rows and {} features".format(len(self._data), len(self._data.columns)))
        self.train_size = train_size

    def initiate_train_data(self):
        """ Initiate data for data preparation """
        self.logger.info("DataInit : Starting Train Data Initialisation")
        self.create_data_and_prod_folders()
        self.map_company_ids()
        self.replace_infinite_values()
        with warnings.catch_warnings():
            warnings.simplefilter("ignore", category=DeprecationWarning)
            self.train_test_split()
        self._test_set.to_csv('data_sandbox/1_DataInitTestSet.csv', index=False, header=True)
        self.logger.info("DataInit : Finished")

    def create_data_and_prod_folders(self):
        """ Create folder paths for data sandbox and for prod if they don't exist """
        data_sandbox_path = '{}/data_sandbox'.format(os.getcwd())
        for_prod_path = '{}/ForProd'.format(os.getcwd())
        # makes data_sandbox directory, this is where untracked files will be stored
        if not os.path.exists(data_sandbox_path):
            os.makedirs(data_sandbox_path)
        # makes ForProd directory, this is where tracked files will be stored
        if not os.path.exists(for_prod_path):
            os.makedirs(for_prod_path)

    def map_company_ids(self):
        """ Replaces company numbers with integer mapping """
        if 'company_id' in self._data.columns:
            self.generate_company_id_mapping()
            self.write_company_id_mapping()
        else:
            sys.exit('Please ensure a column entitled company_id containing the company number is included in the dataset')

    def generate_company_id_mapping(self):
        """ Create mapping for company_ids """
        n_companies = len(self._data)
        integer_mapping = list(range(n_companies))
        self.company_mapping = dict(zip([str(i) for i in integer_mapping], self._data.company_id.astype(str)))
        self._data['company_id'] = integer_mapping

    def write_company_id_mapping(self):
        """ Writes the company_id_mapping """
        with open('{}/data_sandbox/company_mapping.json'.format(os.getcwd()), 'w') as outfile:
            json.dump(self.company_mapping, outfile)

    def replace_infinite_values(self):
        """ Replace infinite values with nans """
        self._data.replace([np.inf, -np.inf], np.nan, inplace=True)

    def train_test_split(self):
        """ 80 / 20 split to create train & test set """
        self._train_set, self._test_set = model_selection.train_test_split(self._data, train_size=self.train_size, random_state=7)
        self.logger.info("DataInit : Saving {} company ids of test_data in {}/data_sandbox/test_data_company_ids.csv".format(len(self._test_set.company_id), os.getcwd()))
        self._test_set.company_id.to_csv('{}/data_sandbox/test_data_company_ids.csv'.format(os.getcwd()))
        self._train_set.company_id.to_csv('{}/data_sandbox/train_data_company_ids.csv'.format(os.getcwd()))
