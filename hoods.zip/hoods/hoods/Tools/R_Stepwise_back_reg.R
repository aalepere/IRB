args = commandArgs(trailingOnly=TRUE)
if (length(args)<2) {
      stop("At least two arguments must be supplied", call.=FALSE)
}
MyData <- read.csv(file=args[1], header=TRUE, sep=",")
MyData$X <- NULL
fullmod <- glm(as.formula(args[2]), family = binomial, data = MyData)
backwards = step(fullmod, trace = 0, direction = "backward")
summary(backwards)
formula(backwards)
