"""
HOODS Step 5 : Transform Features
"""

####################################
# Libraries and Runtime Parameters #
####################################
import warnings
import pandas as pd
from . import hoods_settings
from .Tools import FeatureTransTrain, Timer, research_utils
warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=FutureWarning)
company_size, output_flag, for_prod_dir = hoods_settings.get_runtime_params()

############
# Analysis #
############
logger = research_utils.get_logger(company_size)
timer = Timer.Timer(logger=logger)

# Transform, Scale & Clean - Train

def run():
    ''' run FeatureTrans '''
    timer.initiate_timer('Transform Train set')
    logger.info('FeatTran : Reading prepped data with good gini features from {}'.format(hoods_settings.GINI_ANAL_TOP_FEATURES))
    dataset = pd.read_csv(hoods_settings.GINI_ANAL_TOP_FEATURES, index_col=None)
    featTransTrain = FeatureTransTrain.FeatureTransTrain(data=dataset, output_flag=output_flag, for_prod_dir=for_prod_dir, logger=logger, cores=hoods_settings.CORES_PROD)
    featTransTrain.transform_scale_train_set()
    timer.finish_timer('Transform Train set', 'Transforming, Scaling & Cleaning the train set')
