"""
HOODS Step 10 : Display distributions
"""

####################################
# Libraries and Runtime Parameters #
####################################
import warnings
import pandas as pd
from . import hoods_settings
from .Tools import Timer, research_utils, Distribution
warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=FutureWarning)
company_size, output_flag, for_prod_dir = hoods_settings.get_runtime_params()

############
# Analysis #
############
logger = research_utils.get_logger(company_size)
timer = Timer.Timer(logger=logger)

def run():
    ''' run distribution '''
    timer.initiate_timer('Running distribution')
    train_set = pd.read_csv(hoods_settings.INITIATE_MODEL_TRAIN_SET)
    distribution = Distribution.Distribution(data=train_set, company_size=company_size, output_flag=output_flag,\
					  logger=logger, for_prod_dir=for_prod_dir)
    distribution.show_all_distributions()
    timer.finish_timer('Running distribution', 'Run distribution for train set')
