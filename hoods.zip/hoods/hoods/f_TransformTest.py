"""
HOODS Step 7 : Transform Test Set for Model
"""

####################################
# Libraries and Runtime Parameters #
####################################
import warnings
import pandas as pd
from . import hoods_settings
from .Tools import Timer, research_utils
from .Tools.Modelling import DataPrepTest, FeatureTransTest, transform_utils
warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=FutureWarning)
company_size, output_flag, for_prod_dir = hoods_settings.get_runtime_params()

############
# Analysis #
############
logger = research_utils.get_logger(company_size)
timer = Timer.Timer(logger=logger)

def run():
    ''' run transformtest '''
    timer.initiate_timer('Transform Test Data')
    _data = pd.read_csv(hoods_settings.DATA_INIT_TEST_DATA)
    transform_utils.transform_test(data=_data, DataPrepTest=DataPrepTest.DataPrepTest, FeatTransTest=FeatureTransTest.FeatureTransTest,\
                              for_prod_dir=for_prod_dir, logger=logger, output_flag=output_flag, cores=hoods_settings.CORES_PROD, prod=False)
    timer.finish_timer('Transform Test Data', 'Transform Test Data')
