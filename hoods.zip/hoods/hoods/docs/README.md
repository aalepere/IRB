# Hoods Package

Install using pip3 install -U git+ssh://git@gitlab.com/hokodo/data-science/hoods#egg=hoods

Then, to import the modelling package use from hoods.Tools import Modelling

# HOODS

Framework built to take in company financial and non financial data to develop a machine learning model capable of predicting probability of default.

## How to install

To clone and run this application you will need to have Git and Python3 installed on your computer. From your command line:

    # Clone this repository (this will require an access token)
    $ git clone https://gitlab.com/hokodo/data-science/hoods.git

    # Go into the repository
    $ cd hoods

    # Install the latest version of pip
    $ python3 -m pip install --user --upgrade pip

    # Install virtualenv
    $ python3 -m pip install --user virtualenv

    # Create a virtual environment
    $ python3 -m virtualenv env 

    # Activate the virtual environment
    $ source env/bin/activate

    # (If you wish to leave the virtual environment)
    $ deactivate

    # Install requirements
    $ pip install -r requirements.txt

### 1. Data Preparation

Tools used : DataInitTrain, DataPrepTrain  

DataInitTrain :
- Takes in a dataset
- Splits into train and test set
- INPUTS  : comp\_financials.csv, comp\_non\_financials.csv
- OUTPUTS : test\_data\_company\_ids.csv, train\_data\_company\_ids.csv, 1\_DataInitTestSet.csv

DataPrepTrain :
- Fills select missing values with defaults
- Replaces categoricals with numbers
- Removes columns with too many missing values
- INPUTS  : data\_prep\_column\_clean.json
- OUTPUTS : middle\_value\_transformation.json, cat\_to\_num\_transformation.json, 1\_DataPrepTrain.csv

### 2. Gini Analysis

Tools used : GiniAnalysis

GiniAnalysis :
- Computes gini-coefficient for each feature predicting default 
- INPUTS  : 1\_DataPrepTrain.csv
- OUTPUTS : 2\_features\_to\_remove.csv

### 3. Select Top Features

Tools used : GiniAnalysis

GiniAnalysis :
- Keeps features set to False in features to remove
- INPUTS  : 1\_DataPrepTrain.csv,  2\_features\_to\_remove.csv
- OUTPUTS : 3\_DataTopFeatures.csv

### 4. Single Feature Analysis

Tools used : research\_utils

Research\_utils :
- Function used to generate visualisation of each feature distribution against the default rate
- Allows experimentation on modifying features to remove noise and obtain clear trends
- INPUTS  : 2\_features\_to\_remove.csv, 3\_DataTopFeatures.csv 
- OUTPUTS : Single\_feature\_analysis\_CompanySize.ipynb, transformations\_to\_apply.json

### 5. Feature Transformation

Tools used : FeatureTransTrain

FeatureTransTrain : 
- Performs transformations from SFA
- Transforms and scales features
- INPUTS  : 3\_DataTopFeatures.csv, transformations\_to\_apply.json, customFeatures.csv
- OUTPUTS : 5\_FeatTrans.csv, edges.p, scale.p, mid\_val.p, bin\_index.p, log\_bin\_dict.p

### 6. Test dataset preparation

Tools used : transform\_utils, DataPrepTest, FeatureTransTest

transform\_utils
- INPUTS  : DataPrepTest, FeatureTransTest

DataPrepTest
- Preps test data based on train data specifications
- INPUTS  : middle\_value\_transformation.json, cat\_to\_num\_transformation.json, data\_prep\_column\_clean.json

FeatureTransTest
- Transforms test data based on train data transformations
- INPUTS  : edges.p, scale.p, mid\_val.p, bin\_index.p, log\_bin\_dict.p, transformations\_to\_apply.json
- OUTPUTS : 7\_TransformTest.csv

ModelPreAnalysis.ipynb
- OUTPUTS : remove\_from\_model\_columns.json, model\_parameters.json

### 7. Pre Model Analysis

Tools used : PreModelAnalysis

PreModelAnalysis :
- Removes columns from datasets
- Writes best features to prod 
- INPUTS  : remove\_from\_model\_columns.json
- OUTPUTS : 8\_Train\_data.csv, 8\_Test\_data.csv, prod\_features.json

### 8. Credit Model
	
Tools used : Model

Model :
- Performs logistic regression
- Conducts a gini test
- INPUTS  : 8\_Train\_data.csv, 8\_Test\_data.csv, model\_parameters.json 
- OUTPUTS : model\_coeff\_summary.csv, CreditModel.p

# Directories

- hoods/ contains runtime scripts that carry out each step in the data preparation and model training workflow
- settings/ contains parameter files used to run the HOODS
- Tools/ contains classes employed at each step in the HOODS, as well as utils functions
- envs/ contains environment vairables specific to each model e.g. company\_size

# TESTING

## Unittest
To run test, type (from hoods/hoods/ directory)

    $ python3 -W ignore -m unittest tests/Unittests/test_*

To generate coverage report type, note if you are testing files in Tools it should be written as follows:

    $ python3 -m pytest --cov=Tools/ tests/Unittests/ --cov-report=html:tests/Unittests/coverage
    $ coverage html

then open the htmlcov directory in your browser and select the index.html file

## SmokeTest
to run the SmokeTests, type (from hoods/hoods/ directory)

    $ python3 -W ignore -m unittest tests/SmokeTest/test_*

To generate coverage report type 

    $ python3 -m pytest --cov=Tools/ tests/SmokeTest/ --cov-report=html:tests/SmokeTest/coverage

## DataIntegrityTest
to run the DataIntegrityTest, type(from hoods/hoods/ directory)

    $ python3 -W ignore -m unittest tests/DataIntegrity/test_DataIntegrity.py

To generate coverage report type

    $ py.test --cov=Tools/ --cov=Tools/ tests/DataIntegrity/ --cov-report=html:tests/DataIntegrity/coverage

## Run all the tests
to run all the tests, type(from hoods/hoods/ directory)

    $ python3 -W ignore -m unittest tests/*/test_*
