"""
HOODS Step 9 : Train the Model
"""

####################################
# Libraries and Runtime Parameters #
####################################
import warnings
import pickle
import pandas as pd
from . import hoods_settings
from .Tools import Timer, research_utils
from .Tools.Modelling import Model
warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=FutureWarning)
company_size, output_flag, for_prod_dir = hoods_settings.get_runtime_params()

############
# Analysis #
############
logger = research_utils.get_logger(company_size)
timer = Timer.Timer(logger=logger)

def run():
    ''' run model '''
    timer.initiate_timer('Running model')
    train_set = pd.read_csv(hoods_settings.INITIATE_MODEL_TRAIN_SET)
    test_set = pd.read_csv(hoods_settings.INITIATE_MODEL_TEST_SET)
    model = Model.Model(train_set=train_set, test_set=test_set, output_flag=output_flag, logger=logger, for_prod_dir=for_prod_dir, company_size=company_size)
    model.run_all_functions()
    timer.finish_timer('Running model', 'Run model summary for the given train and test')
