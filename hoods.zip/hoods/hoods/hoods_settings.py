''' Settings file containing model parameters and settings functions '''

# The following will be set to a value by the specific credit model
CORES_PROD = 0
FOR_PROD_DIR = 0
OUTPUT_FLAG = 0
DATASETS_DIR = 0
DATA_FILE_NAME = 0
TRAIN_SIZE = 0
MISSING_THRESHOLD = 0

# Directory paths
DATA_INIT_TEST_DATA = "data_sandbox/1_DataInitTestSet.csv"
DATA_PREP_OUT = "data_sandbox/1_DataPrepTrain.csv"
FEATURES_TO_REMOVE = "2_features_to_remove.csv"
GINI_ANAL_TOP_FEATURES = "data_sandbox/3_DataTopFeatures.csv"
PRE_MODEL_TRAIN_SET = "data_sandbox/5_FeatTrans.csv"
PRE_MODEL_TEST_SET = "data_sandbox/7_TransformTest.csv"
INITIATE_MODEL_TRAIN_SET = "data_sandbox/8_Train_data.csv"
INITIATE_MODEL_TEST_SET = "data_sandbox/8_Test_data.csv"

def get_initiation_params():
    ''' function to read environment variables for data initiation '''
    import os
    company_size = os.getcwd().split('/')[-1]
    datasets_dir = DATASETS_DIR
    dataset_path = DATASETS_DIR + DATA_FILE_NAME
    output_flag = OUTPUT_FLAG
    for_prod_dir = FOR_PROD_DIR
    missing_threshold = MISSING_THRESHOLD
    train_size = TRAIN_SIZE
    return company_size, datasets_dir, dataset_path, output_flag, for_prod_dir, missing_threshold, train_size

def get_runtime_params():
    ''' Function to read environment variables and model params otherwise runtime error '''
    import os
    company_size = os.getcwd().split('/')[-1]
    output_flag = OUTPUT_FLAG
    for_prod_dir = FOR_PROD_DIR
    return company_size, output_flag, for_prod_dir
