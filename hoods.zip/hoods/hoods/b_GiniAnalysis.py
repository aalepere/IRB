"""
HOODS Step 2 : Gini Analysis
"""

####################################
# Libraries and Runtime Parameters #
####################################
import warnings
import pandas as pd
from . import hoods_settings
from .Tools import GiniAnalysis, Timer, research_utils
warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=FutureWarning)
company_size, output_flag, for_prod_dir = hoods_settings.get_runtime_params()

############
# Analysis #
############

logger = research_utils.get_logger(company_size)
timer = Timer.Timer(logger=logger)

def run():
    ''' run 2_GiniAnalysis '''
    timer.initiate_timer('Gini Analysis')
    logger.info('GiniAnal : Reading prepped data from {}'.format(hoods_settings.DATA_PREP_OUT))
    DataPrepOutput = pd.read_csv(hoods_settings.DATA_PREP_OUT, index_col=None)
    giniAnal = GiniAnalysis.GiniAnalysis(data=DataPrepOutput, output_flag=output_flag, logger=logger)
    giniAnal.retrieve_gini_analysis()
    timer.finish_timer('Gini Analysis', 'Running Gini analysis')
