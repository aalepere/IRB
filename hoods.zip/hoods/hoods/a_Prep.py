"""
HOODS Step 1 : Prepare the data
"""

####################################
# Libraries and Runtime Parameters #
####################################
import warnings
from . import hoods_settings
from .Tools import DataInitTrain, DataPrepTrain, Timer, research_utils
warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=FutureWarning)
company_size, datasets_dir, dataset_path, output_flag, for_prod_dir, missing_threshold, train_size = hoods_settings.get_initiation_params()

############
# Analysis #
############
logger = research_utils.get_logger(company_size)
timer = Timer.Timer(logger=logger)

def run():
    ''' run 1_prep.py '''
    timer.initiate_timer('Initiate data')
    dataInit = DataInitTrain.DataInitTrain(data_path=dataset_path, company_size=company_size, train_size=train_size, logger=logger)
    dataInit.initiate_train_data()
    timer.finish_timer('Initiate data', 'Initialising the dataset and splitting it')

    timer.initiate_timer('Preparing data')
    dataPrep = DataPrepTrain.DataPrepTrain(data=dataInit._train_set, output_flag=output_flag, missing_threshold=missing_threshold, for_prod_dir=for_prod_dir, logger=logger, datasets_dir=datasets_dir)
    dataPrep.prepare_train_data()
    timer.finish_timer('Preparing data', 'Filling missing values and cleaning data')
