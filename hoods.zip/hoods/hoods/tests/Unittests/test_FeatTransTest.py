''' Tests for FeatTrans.py '''
import importlib
import unittest
import warnings
from random import shuffle
from unittest.mock import MagicMock, patch

import pandas as pd

from Tools.Modelling import FeatureTransTest

warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=FutureWarning)

class testFeatTransTest(unittest.TestCase):
    ''' unittest subclass for feature trans test '''

    def setUp(self):
        top_features_financials = pd.read_csv('tests/Unittests/data/top_features.csv')
        self.featTransTest = FeatureTransTest.FeatureTransTest(data=top_features_financials, prod=False, logger=MagicMock(), output_flag='liq_flg',\
                for_prod_dir='tests/ForProd_test/PACKAGE_TEST/', cores=1)
        module = importlib.import_module('tests.ForProd_test.PACKAGE_TEST.transformations_to_apply')
        importlib.reload(module)
        self.featTransTest.trans_to_apply = module.transformations_to_apply


    @patch('Tools.Modelling.FeatureTransTest.pd.DataFrame.to_csv')
    def test_transform_scale_test_set(self, mock):
        ''' test for FeatureTransTest.transform() '''
        self.featTransTest.central_tendency_mapping = {'comp_number_2digit_cat' : 3, 'replacement_feature' : 4}
        self.featTransTest.log_odds_mapping = {'replacement_feature': {(0, 1), (5, 6), (3, 4)}, 'comp_number_2digit_cat': {(0, 1)}}
        self.featTransTest.scale_metrics_mapping = {'replacement_feature_logOR': [0, 1], 'comp_number_2digit_cat_logOR': [0, 1]}
        self.featTransTest.transform_scale_test_set()
        self.assertEqual(list(self.featTransTest._data.replacement_feature_logOR_stand)[-5:], [4.0, 6.0, 6.0, 1.0, 4.0])

    def test_replace_missing_with_train_central_tendency(self):
        ''' test for replace_missing_with_train_central_tendency '''
        self.featTransTest.central_tendency_mapping = {'replacement_feature': 72}
        dataframe = self.featTransTest.replace_missing_with_train_central_tendency(self.featTransTest._data, 'replacement_feature')
        self.assertEqual(dataframe.replacement_feature.tolist()[-4:], [5.0, 8.0, 0.0, 72.0])

    def test_discretize_using_train_bins(self):
        ''' test for discretize_using_train_bins '''
        self.featTransTest.disc_own_bin_index_mapping = {'replacement_feature': [3, 4]}
        self.featTransTest.disc_bin_edges_mapping = {'replacement_feature': [2.0, 3.66666667, 4.33333333, 8.0]}
        dataframe = self.featTransTest.discretize_using_train_bins(self.featTransTest._data, 'replacement_feature', own_bins=[0, 'nan'])
        self.assertEqual(list(dataframe.replacement_feature_disc[-4:]), [2.0, 2.0, 3.0, 4.0])

    def test_scale_test_feature(self):
        ''' test for scale_test_feature '''
        self.featTransTest.scale_metrics_mapping = {'comp_number_2digit_cat': [1, 2]}
        dataframe = self.featTransTest.scale_test_feature(self.featTransTest._data, 'comp_number_2digit_cat')
        self.assertEqual(dataframe.comp_number_2digit_cat_stand.tolist()[0:5], [4.0, 0.5, 9.5, 0.5, 2.5])

    def test_transform_test_log_odds_random_index(self):
        ''' test for transform_test_log_odds '''
        self.featTransTest.log_odds_mapping = {'comp_number_2digit_cat': {(9, 8), (2, 1), (20, 19), (6, 5), (1, 0), (4, 3)}}
        # Test transforming random index 
        indexes = list(self.featTransTest._data.index)
        shuffle(indexes)
        self.featTransTest._data.index = indexes
        dataframe = self.featTransTest.transform_test_log_odds(self.featTransTest._data, 'comp_number_2digit_cat')
        self.assertEqual(dataframe.comp_number_2digit_cat_logOR.tolist()[0:5], [8.0, 1.0, 19.0, 1.0, 5.0])

    def test_transform_test_log_odds(self):
        ''' test for transform_test_log_odds '''
        self.featTransTest.log_odds_mapping = {'comp_number_2digit_cat': {(9, 8), (2, 1), (20, 19), (6, 5), (1, 0), (4, 3)}}
        dataframe = self.featTransTest.transform_test_log_odds(self.featTransTest._data, 'comp_number_2digit_cat')
        self.assertEqual(dataframe.comp_number_2digit_cat_logOR.tolist()[0:5], [8.0, 1.0, 19.0, 1.0, 5.0])

    def test_transform_and_scale_test_set_feature(self):
        ''' test for transform_and_scale_test_set_feature '''
        self.featTransTest.trans_to_apply['replacement_feature']["discretize"]["own_bins"] = []
        self.featTransTest.central_tendency_mapping = {'replacement_feature': 72}
        self.featTransTest.log_odds_mapping = {'replacement_feature': {(5, 5), (8, 8), (0, 0), (72, 72)}}
        self.featTransTest.scale_metrics_mapping = {'replacement_feature_logOR': [0, 1]}
        dataframe = self.featTransTest.transform_and_scale_test_set_feature('replacement_feature')
        self.assertEqual(list(dataframe.replacement_feature_logOR_stand[-4:]), [5.0, 8.0, 0.0, 72.0])

    def test_transform_and_scale_test_set_feature_discretize_own_bins_nan(self):
        ''' test for transform_and_scale_test_set_feature, own_bins with nan, discretize '''
        self.featTransTest.trans_to_apply['replacement_feature']["discretize"]["own_bins"] = ["nan"]
        self.featTransTest.trans_to_apply['replacement_feature']["discretize"]["apply"] = 1
        self.featTransTest.disc_own_bin_index_mapping = {'replacement_feature': [3]}
        self.featTransTest.disc_bin_edges_mapping = {'replacement_feature': [2.0, 3.66666667, 4.33333333, 8.0]}
        self.featTransTest.log_odds_mapping = {'replacement_feature_disc': {(2, 2), (0, 0), (3, 3)}}
        self.featTransTest.scale_metrics_mapping = {'replacement_feature_disc_logOR': [0, 1]}
        dataframe = self.featTransTest.transform_and_scale_test_set_feature('replacement_feature')
        self.assertEqual(list(dataframe.replacement_feature_disc_logOR_stand[-4:]), [2.0, 2.0, 0.0, 3.0])

    def test_transform_and_scale_test_set_feature_discretize_own_bins(self):
        ''' test for transform_and_scale_test_set_feature, own_bins without nan, discretize '''
        self.featTransTest.trans_to_apply['replacement_feature']['discretize']["own_bins"] = [0]
        self.featTransTest.trans_to_apply['replacement_feature']['discretize']["apply"] = 1
        self.featTransTest.central_tendency_mapping = {'replacement_feature': 4.0}
        self.featTransTest.disc_own_bin_index_mapping = {'replacement_feature': [3]}
        self.featTransTest.disc_bin_edges_mapping = {'replacement_feature': [2.0, 3.66666667, 4.33333333, 8.0]}
        self.featTransTest.log_odds_mapping = {'replacement_feature_disc': {(2, 2), (3, 3), (1, 1)}}
        self.featTransTest.scale_metrics_mapping = {'replacement_feature_disc_logOR': [0, 1]}
        dataframe = self.featTransTest.transform_and_scale_test_set_feature('replacement_feature')
        self.assertEqual(list(dataframe.replacement_feature_disc_logOR_stand[-4:]), [2.0, 2.0, 3.0, 1.0])

    def test_and_scale_test_set_feature_fit(self):
        ''' test for transform_and_scale_test_set_feature, fit '''
        self.featTransTest.trans_to_apply['replacement_feature']['fit']["apply"] = 1
        self.featTransTest.central_tendency_mapping = {'replacement_feature': 4.0}
        self.featTransTest.log_odds_mapping = {'replacement_feature_fit': {(5, 5), (8, 8), (0, 0), (4, 4)}}
        self.featTransTest.scale_metrics_mapping = {'replacement_feature_fit_logOR': [0, 1]}
        dataframe = self.featTransTest.transform_and_scale_test_set_feature('replacement_feature')
        self.assertEqual(list(dataframe.replacement_feature_fit_logOR_stand[-4:]), [5.0, 8.0, 0.0, 4.0])

if __name__ == '__main__':
    unittest.main()
