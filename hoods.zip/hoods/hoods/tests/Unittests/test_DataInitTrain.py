''' Tests for DataInitTrain class  '''
import unittest
import warnings
from unittest.mock import patch, MagicMock
import numpy as np
from Tools import DataInitTrain
warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=FutureWarning)

class testDataInitTrain(unittest.TestCase):
    ''' test for data init for training data set '''

    def setUp(self):
        self.DataInitTrain = DataInitTrain.DataInitTrain(data_path='tests/Unittests/data/full_dataset_sample.csv', company_size='Small', train_size=0.8, logger=MagicMock())

    @patch('Tools.DataInitTrain.pd.DataFrame.to_csv')
    @patch('Tools.DataInitTrain.pd.Series.to_csv')
    @patch('Tools.DataInitTrain.DataInitTrain.write_company_id_mapping')
    @patch('Tools.DataInitTrain.os.makedirs')
    def test_initiate_data(self, mock1, mock2, mock3, mock4):
        ''' test for initiate_train_data '''
        self.DataInitTrain.initiate_train_data()
        self.assertEqual(list(self.DataInitTrain._data.company_id), [0, 1, 2])


    def test_replace_infinite_values(self):
        ''' test for replace_infinite_value '''
        self.DataInitTrain.replace_infinite_values()
        self.assertFalse(np.inf in self.DataInitTrain._data.NetIncome.tolist())
        self.assertFalse(-np.inf in self.DataInitTrain._data.NetIncome.tolist())

    def test_generate_company_id_mapping(self):
        ''' test for generate_company_id_mapping '''
        self.DataInitTrain.generate_company_id_mapping()
        self.assertEqual(self.DataInitTrain.company_mapping, {"0": "2051155", "1": "431565", "2": "132522"})

    @patch('Tools.DataInitTrain.DataInitTrain.write_company_id_mapping')
    def test_map_company_ids(self, mock):
        ''' test for map_company_ids '''
        self.DataInitTrain.map_company_ids()
        self.assertEqual(self.DataInitTrain._data.company_id.tolist(), [0, 1, 2])

    @patch('Tools.DataInitTrain.pd.Series.to_csv')
    def test_train_test_split(self, mock):
        ''' test for train_test_split '''
        self.DataInitTrain.train_test_split()
        self.assertEqual(self.DataInitTrain._test_set.company_id.tolist(), [132522])

if __name__ == '__main__':
    unittest.main()
