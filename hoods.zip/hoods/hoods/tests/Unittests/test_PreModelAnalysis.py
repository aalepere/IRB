''' Test for PreModelAnalysis '''
import importlib
import unittest
import warnings
import os
from unittest.mock import MagicMock
from Tools import PreModelAnalysis, research_utils
warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=FutureWarning)

class testPreModelAnalysis(unittest.TestCase):
    ''' test for PremodelAnalysis Class '''

    def setUp(self):
        train_data_path = 'tests/Unittests/data/train_model_sample.csv'
        self.PreModel = PreModelAnalysis.PreModelAnalysis(data_path=train_data_path, logger=MagicMock(),\
                output_flag='liq_flg', for_prod_dir='tests/ForProd_test/PACKAGE_TEST/')

    def tearDown(self):
        path = 'tests.ForProd.PACKAGE_TEST.prod_features'
        if os.path.isfile(path):
            os.remove(path)

    def test_remove_features(self):
        ''' test for remove features function in PreModelAnalysis class '''
        self.PreModel.remove_features()
        self.assertFalse('NetIncome' in self.PreModel._data.columns)

if __name__ == '__main__':
    unittest.main()
