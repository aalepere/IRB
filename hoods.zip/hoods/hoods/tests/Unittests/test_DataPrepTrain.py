''' Test for data DataPrepTrain '''
import unittest
from unittest.mock import patch, MagicMock
import warnings
import pandas as pd
from Tools import DataPrepTrain
warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=FutureWarning)

class testDataPrepTrain(unittest.TestCase):
    ''' tests for DataPrepTrain Class '''

    def setUp(self):
        self.DataPrepTrain = DataPrepTrain.DataPrepTrain(data=pd.read_csv('tests/Unittests/data/train_set.csv', index_col=None),\
                for_prod_dir='tests/Unittests/data/ForProd/', output_flag='liq_flg', missing_threshold=0.70, logger=MagicMock(), datasets_dir='tests/Unittests/data/')

    def test_load_default_value_features(self):
        ''' test for load_default_value_features '''
        self.DataPrepTrain.load_default_value_features()
        self.assertEqual(self.DataPrepTrain.cols_to_replace, [{'columns': ['sic_1'], 'type': 'FillEmptyWithValue', 'value': 'Undefined'}])

    @patch('Tools.DataPrepTrain.DataPrepTrain.load_default_value_features', return_value=None)
    def test_convert_missing_values_to_default(self, mock):
        ''' test for convert_missing_values_to_default '''
        self.DataPrepTrain.cols_to_replace = [{'columns': ['sic_1'], 'value': 'Undefined'}]
        self.DataPrepTrain.convert_missing_values_to_default()
        self.assertEqual(self.DataPrepTrain._data.sic_1.tolist()[1], 'Undefined')
        self.assertEqual(self.DataPrepTrain.default_value_mappings['sic_1'], 'Undefined')

    def test_load_categorical_features(self):
        ''' test for load_categorical_features '''
        self.DataPrepTrain.load_categorical_features()
        self.assertEqual(self.DataPrepTrain.non_numeric_cols, ['sic_1'])

    @patch('Tools.DataPrepTrain.DataPrepTrain.load_categorical_features', return_value=None)
    def test_convert_cat_to_num_features(self, mock):
        ''' test for convert_cat_to_num_features '''
        self.DataPrepTrain.non_numeric_cols = ['sic_1']
        self.DataPrepTrain.convert_cat_to_num_features()
        self.assertEqual(self.DataPrepTrain._data.sic_1_cat.tolist()[2:5], [1.0, 1.0, 1.0])
        self.assertEqual(self.DataPrepTrain.cat_to_num_mappings['sic_1']['sic_1_cat']['Licensed restaurants'], 1.0)

    def test_remove_cols_too_many_missing(self):
        ''' test for remove_cols_too_many_missing '''
        self.DataPrepTrain.remove_cols_too_many_missing()
        self.assertTrue('NetIncome' not in self.DataPrepTrain._data.columns)

if __name__ == '__main__':
    unittest.main()
