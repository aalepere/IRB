"""
Description: Test for Calibration.py script
"""

#############
# Libraries #
#############
import unittest
import warnings
from unittest.mock import MagicMock, patch
import numpy as np
import pandas as pd
from Tools import Calibration
warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=FutureWarning)


########################################
# Class that contains unittest methods #
########################################
class testCalibration(unittest.TestCase):
    """ Class containing unittest methods """

    def setUp(self):
        self.Calibration = Calibration.Calibration(data=None, bin_number=10, performance_window=6,\
                anchor_point=0.93, company_size='test', output_flag='liq_flg',\
                for_prod_dir='tests/ForProd_test/PACKAGE_TEST/', logger=MagicMock(), add_constraint=True)

    def test_create_calibration_dataframe(self):
        """ unittest for function create_calibration_dataframe """
        score_df = pd.read_csv('tests/Unittests/data/calibration_sample.csv', index_col=None)
        self.Calibration.grouped_bins = score_df.groupby(['bin'], as_index=False)
        self.Calibration.create_calibration_dataframe()
        self.assertEqual(self.Calibration.cal_df['pd_in_bin'].tolist(), [0.9354568315171836, 0.9354568315171836, 0.8579335793357933, 0.9747789059941042])
        self.assertEqual(self.Calibration.cal_df['median_score'].tolist(), [-6.5, -5.5, -5.0, -3.0])

    @patch('Tools.Calibration.write_to_python_file')
    def test_calibrate_model_without_constraint(self, mock):
        """ unittest for function calibrate_model """
        self.Calibration.add_constraint = False
        self.Calibration.cal_df = pd.DataFrame({
            'median_score': [-4.5, -4.0, -3.8, -2.8],
            'pd_in_bin': [0.00061, 0.00295, 0.00437, 0.0418],
            'total_companies': [1000, 1000, 1000, 1000]})
        self.Calibration.calibrate_model()
        self.assertEqual(self.Calibration.cal_df['fitted_pd'].tolist(), [
            0.0006194661818805396, 0.0027301542453611366, 0.004671823684294887, 0.04159403685515421])

    @patch('Tools.Calibration.write_to_python_file')
    def test_calibrate_model_with_constraint(self, mock):
        """ unittest for function calibrate_model """
        self.Calibration.add_constraint = True
        self.Calibration.cal_df = pd.DataFrame({
            'median_score': [-4.5, -4.0, -3.8, -2.8],
            'pd_in_bin': [0.00061, 0.00295, 0.00437, 0.0418],
            'total_companies': [1000, 1000, 1000, 1000]})
        self.Calibration.calibrate_model()
        self.assertEqual(self.Calibration.cal_df['fitted_pd'].tolist(), [
            0.7196808729638974, 0.9999234520023464, 0.9999956686735926, 0.999999999739063])

    def test_objective_function(self):
        """ unittest for objective function """
        x = np.array([1, 0.1, 0.01])
        t = np.array([-2, -4])
        result = self.Calibration.objective_function(x=x, t=t, y=4)
        self.assertEqual(result, 316.1036475785887)

    def test_calculate_fitted_pd(self):
        """ unittest for calculate fitted pd """
        x = np.array([1, 0.1, 0.01])
        t = np.array([-2, -4])
        result = self.Calibration.calculate_fitted_pd(x=x, t=t)
        self.assertEqual(result.tolist(), [0.02166826631696054, 1.66212264070052e-07])
