''' Tests for FeatTrans.py '''
import unittest
import importlib
import os
import warnings
import pandas as pd
from unittest.mock import MagicMock
from Tools import FeatureTransTrain, research_utils
warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=FutureWarning)

class TestFeatTransTrain(unittest.TestCase):
    ''' unittests for FeatTransTrain '''

    def setUp(self):
        _data = pd.read_csv('tests/Unittests/data/top_features.csv')
        for_prod_dir = 'tests/ForProd_test/PACKAGE_TEST/'
        self.featTransTrain = FeatureTransTrain.FeatureTransTrain(data=_data, for_prod_dir=for_prod_dir,\
                output_flag='liq_flg', logger=MagicMock(), cores=1)
        module = importlib.import_module('tests.ForProd_test.PACKAGE_TEST.transformations_to_apply')
        importlib.reload(module)
        self.featTransTrain.trans_to_apply = module.transformations_to_apply

    def test_transform_feature_remove_own_bins_nan(self):
        ''' test for transform_feature, own_bins with nan, remove value '''
        self.featTransTrain.trans_to_apply["replacement_feature"]["discretize"]["own_bins"] = ["nan"]
        self.featTransTrain.trans_to_apply["replacement_feature"]["remove"]["apply"] = 1
        feature_object = self.featTransTrain.transform_feature('replacement_feature')
        self.assertEqual(list(feature_object[0].replacement_feature_disc[-4:]), [1.0, 2.0, 2.0, 3.0])

    def test_transform_feature_group_own_bins_nan(self):
        ''' test for transform_feature, own_bins with nan, group values '''
        self.featTransTrain.trans_to_apply["replacement_feature"]['discretize']['own_bins'] = ['nan']
        self.featTransTrain.trans_to_apply["replacement_feature"]["group"]["apply"] = 1
        feature_object = self.featTransTrain.transform_feature('replacement_feature')
        self.assertEqual(list(feature_object[0].replacement_feature_disc[-4:]), [1.0, 1.0, 0.0, 2.0])

    def test_transform_feature_winsorize_own_bins_nan(self):
        ''' test for transform_feature, own_bins with nan, winsorize '''
        self.featTransTrain.trans_to_apply["replacement_feature"]['discretize']['own_bins'] = ['nan']
        self.featTransTrain.trans_to_apply["replacement_feature"]["winsorize"]["apply"] = 1
        feature_object = self.featTransTrain.transform_feature('replacement_feature')
        self.assertEqual(list(feature_object[0].replacement_feature_disc[-4:]), [0.0, 0.0, 0.0, 1.0])

    def test_transform_feature_remove_own_bins(self):
        ''' test for transform_feature, own_bins with 0, remove value '''
        self.featTransTrain.trans_to_apply["replacement_feature"]['discretize']['own_bins'] = [0]
        self.featTransTrain.trans_to_apply["replacement_feature"]["remove"]["apply"] = 1
        self.featTransTrain.trans_to_apply["replacement_feature"]["remove"]["remove_val"] = 4
        feature_object = self.featTransTrain.transform_feature('replacement_feature')
        self.assertEqual(list(feature_object[0].replacement_feature_disc), [0.0, 0.0, 1.0, 2.0, 3.0])

    def test_transform_feature_group_own_bins(self):
        ''' test for transform_feature, own_bins with 0, group values '''
        self.featTransTrain.trans_to_apply["replacement_feature"]['discretize']['own_bins'] = [0]
        self.featTransTrain.trans_to_apply["replacement_feature"]["group"]["apply"] = 1
        self.featTransTrain.trans_to_apply["replacement_feature"]["group"]["cutoff"] = 5
        feature_object = self.featTransTrain.transform_feature('replacement_feature')
        self.assertEqual(list(feature_object[0].replacement_feature_disc[-5:]), [0.0, 1.0, 1.0, 0.0, 2.0])

    def test_transform_feature_winsorize_own_bins(self):
        ''' test for transform_feature, own_bins with 0, winsorize '''
        self.featTransTrain.trans_to_apply["replacement_feature"]["discretize"]["own_bins"] = [0]
        self.featTransTrain.trans_to_apply["replacement_feature"]["winsorize"]["apply"] = 1
        self.featTransTrain.trans_to_apply["replacement_feature"]["winsorize"]["threshold"] = 0.2
        feature_object = self.featTransTrain.transform_feature('replacement_feature')
        self.assertEqual(list(feature_object[0].replacement_feature_disc[-5:]), [0.0, 1.0, 1.0, 0.0, 2.0])

    def test_transform_feature_remove_fit(self):
        ''' test for transform_feature, no own_bins, remove, fit '''
        self.featTransTrain.trans_to_apply["comp_number_2digit_cat"]["remove"]["apply"] = 1
        self.featTransTrain.trans_to_apply["comp_number_2digit_cat"]["fit"]["apply"] = 1
        feature_object = self.featTransTrain.transform_feature('comp_number_2digit_cat')
        self.assertEqual(list(feature_object[0].comp_number_2digit_cat_fit[:5]), [1.9999999955459995, 1.9999999955459995, 1.9999999955459995, 1.160883731643992, 9.472135899025261])

    def test_transform_feature_group_fit(self):
        ''' test for transform_feature, no own_bins, group values, fit '''
        self.featTransTrain.trans_to_apply["comp_number_2digit_cat"]["group"]["apply"] = 1
        self.featTransTrain.trans_to_apply["comp_number_2digit_cat"]["fit"]["apply"] = 1
        feature_object = self.featTransTrain.transform_feature('comp_number_2digit_cat')
        self.assertEqual(list(feature_object[0].comp_number_2digit_cat_fit[:5]), [1.0229881344845548, 1.9999999955459995, 1.9999999955459995, 1.9999999955459995, 1.0229881344845548])

    def test_transform_feature_winsorise_fit(self):
        ''' test for transform_feature, no own_bins, group values, fit '''
        self.featTransTrain.trans_to_apply["comp_number_2digit_cat"]["winsorize"]["apply"] = 1
        self.featTransTrain.trans_to_apply["comp_number_2digit_cat"]["fit"]["apply"] = 1
        feature_object = self.featTransTrain.transform_feature('comp_number_2digit_cat')
        self.assertEqual(list(feature_object[0].comp_number_2digit_cat_fit[:5]), [1.9999999955459995, 1.9999999955459995, 1.9999999955459995, 1.9999999955459995, 1.3546924357157653])

    def test_transform_feature_discretize(self):
        ''' test for transform_feature, no own_bins, discretize '''
        self.featTransTrain.trans_to_apply["replacement_feature"]["discretize"]["apply"] = 1
        self.featTransTrain.trans_to_apply["replacement_feature"]["discretize"]["new_edges"] = [0, 2, 12]
        feature_object = self.featTransTrain.transform_feature('replacement_feature')
        self.assertEqual(list(feature_object[0].replacement_feature_disc[-4:]), [1, 1, 0, 1])

    def test_scale_all_features(self):
        ''' test for scale_all_features '''
        self.featTransTrain.scale_all_features()
        self.assertTrue('comp_number_2digit_cat' not in list(self.featTransTrain._data.columns))
        self.assertEqual(list(self.featTransTrain._data.comp_number_2digit_cat_stand)[-4:], [0.04214497519610896, -0.8007545287260702, -0.2950148263727627, -0.6321746279416344])

if __name__ == "__main__":
    unittest.main()
