"""
Description: Test for GiniAnalysis.py script
"""

#############
# Libraries #
#############
import unittest
import os
import warnings
import pandas as pd
from unittest.mock import MagicMock
from Tools import GiniAnalysis, research_utils
warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=FutureWarning)


########################################
# Class that contains unittest methods #
########################################
class testGiniAnalysis(unittest.TestCase):
    """ Class containing unittest methods """

    def setUp(self):
        _data_test = pd.read_csv('tests/Unittests/data/gini_anal_sample.csv', index_col=None)
        self.GiniAnal = GiniAnalysis.GiniAnalysis(data=_data_test, logger=MagicMock(), output_flag='liq_flg')

    def tearDown(self):
        os.remove('2_features_to_remove.csv')

    def test_retrieve_gini_analysis(self):
        """ unittest for function retrieve_gini_analysis """
        self.GiniAnal.retrieve_gini_analysis()
        _data = pd.read_csv('2_features_to_remove.csv')
        self.assertEqual(_data.iloc[2].tolist()[0:5], [4, 'A', -0.06938, 0.06938, False])

    def test_read_exclusion_list(self):
        """unittest for keep_top_features"""
        self.GiniAnal.retrieve_gini_analysis()
        df = pd.read_csv('2_features_to_remove.csv', index_col=0)
        df_list = df.values.tolist()
        df_list[0][3] = 'True'
        df = pd.DataFrame(df_list, columns=df.columns)
        df.to_csv('2_features_to_remove.csv', index=True)
        self.GiniAnal.filter_unwanted_features()
        self.assertTrue('B' not in self.GiniAnal._data)
        self.assertEqual(set(self.GiniAnal._data), set(['A', 'C', 'D', 'E', 'liq_flg', 'company_id']))
        self.assertEqual(set(self.GiniAnal._data.columns), set(['company_id', 'liq_flg', 'A', 'C', 'D', 'E', 'company_id', 'liq_flg']))

if __name__ == "__main__":
    unittest.main()
