''' Test for data DataPrepTest '''
import unittest
import warnings
from unittest.mock import MagicMock
import pandas as pd
from Tools.Modelling import DataPrepTest
warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=FutureWarning)

class testDataPrepTest(unittest.TestCase):
    ''' unittests for DataPrepTest Class '''

    def setUp(self):
        self.DataPrepTest = DataPrepTest.DataPrepTest(data=pd.read_csv('tests/Unittests/data/train_set.csv', index_col=None), for_prod_dir='tests/ForProd_test/PACKAGE_TEST/', output_flag='liq_flg', logger=MagicMock())

    def test_load_train_data_default_value_mappings(self):
        ''' test for load_train_data_default_value_mappings '''
        self.DataPrepTest.load_train_data_default_value_mappings()
        self.assertEqual(self.DataPrepTest.default_value_mappings, {'sic_1': 'Undefined'})

    def test_convert_test_data_with_default_value_mappings(self):
        ''' test for convert_test_data_with_default_value_mappings '''
        self.DataPrepTest.default_value_mappings = {'sic_1': 'Undefined'}
        self.DataPrepTest.convert_test_data_with_default_value_mappings()
        self.assertEqual(self.DataPrepTest._data.sic_1.tolist()[1], 'Undefined')

    def test_convert_test_data_with_cat_to_num_mappings(self):
        ''' test for convert_test_data_with_cat_to_num_mappings '''
        self.DataPrepTest.load_train_data_cat_to_num_mappings()
        self.DataPrepTest.convert_test_data_with_cat_to_num_mappings()
        self.assertEqual(self.DataPrepTest._data.sic_1_cat.tolist()[0], 11)
        self.assertEqual(self.DataPrepTest._data.sic_1_cat.fillna('NAN').tolist()[1], 'NAN')

if __name__ == '__main__':
    unittest.main()
