''' tests for Tools.research_utils '''
import unittest
import warnings
import pandas as pd
from numpy import inf
from Tools import research_utils
warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=FutureWarning)

class TestResearchUtils(unittest.TestCase):
    ''' test for Tools.research_utils '''

    def setUp(self):
        self.data = pd.read_csv('tests/Unittests/data/top_features.csv', index_col=None)

    def test_compute_default_rate(self):
        ''' test for compute default rate in research_utils '''
        data = research_utils.compute_default_rate(data=self.data, feature='default_feature', output_flag='liq_flg')
        self.assertEqual(list(data.default_feature_DR)[0:4], [0.75, 0.50, 0.75, 0.50])

    def test_compute_gini(self):
        ''' test for compute gini in research_utils '''
        gini = research_utils.compute_gini(self.data, 'default_feature', output_flag='liq_flg')
        self.assertEqual(gini, -0.2666666666666666)

    def test_replace_missing_with_central_tendency_mean(self):
        ''' test for replace_missing_with_central_tendency rep_method equal to the mean '''
        dataframe, missing = research_utils.replace_missing_with_central_tendency(dataframe=self.data, column='replacement_feature', rep_method='mean')
        self.assertEqual(dataframe.replacement_feature.values[-1], 3.7142857142857144)
        self.assertEqual(missing['replacement_feature'], 3.7142857142857144)

    def test_replace_missing_with_central_tendency_mode(self):
        ''' test for replace_missing_with_central_tendency rep_method equal to the mode '''
        dataframe, missing = research_utils.replace_missing_with_central_tendency(dataframe=self.data, column='replacement_feature', rep_method='mode')
        self.assertEqual(dataframe.replacement_feature.values[-1], 4)
        self.assertEqual(missing['replacement_feature'], 4)

    def test_replace_missing_with_central_tendency_median(self):
        ''' test for replace_missing_with_central_tendency rep_method equal to the median '''
        dataframe, missing = research_utils.replace_missing_with_central_tendency(dataframe=self.data, column='replacement_feature', rep_method='median')
        self.assertEqual(dataframe.replacement_feature.values[-1], 4)
        self.assertEqual(missing['replacement_feature'], 4)

    def test_remove_specific_value(self):
        ''' test for remove_specific_value '''
        dataframe = research_utils.remove_specific_value(dataframe=self.data, column='comp_number_2digit_cat', remove_val=1)
        self.assertEqual(list(dataframe.comp_number_2digit_cat)[-4:], [2.0, 6.0, 4.0, 2.0])

    def test_group_values_together(self):
        ''' test for group_values_together '''
        dataframe = research_utils.group_values_together(dataframe=self.data, column='comp_number_2digit_cat', cutoff=9)
        self.assertEqual(list(dataframe.comp_number_2digit_cat)[:5], [9.0, 2.0, 9.0, 2.0, 6.0])

    def test_winsorize_column(self):
        ''' test for winsorize '''
        dataframe = research_utils.winsorize_column(dataframe=self.data, column='comp_number_2digit_cat', threshold=0.2)
        self.assertEqual(list(dataframe.comp_number_2digit_cat)[2:6], [9.0, 2.0, 6.0, 2.0])

    def test_fit_function_two(self):
        ''' test for fit_function with 2 parameters '''
        dataframe, popt = research_utils.fit_function(dataframe=self.data, column='comp_number_2digit_cat', params=2, output_flag='liq_flg')
        self.assertEqual(list(popt), [-10.354865834021272, 20.01658453130073])
        self.assertTrue('comp_number_2digit_cat_DR' in dataframe.columns)

    def test_fit_function_three(self):
        ''' test for fit_function with 3 parameters '''
        dataframe, popt = research_utils.fit_function(dataframe=self.data, column='comp_number_2digit_cat', params=3, output_flag='liq_flg')
        self.assertEqual(list(popt), [-0.3473183148909992, 1.0779909733119064, 1.0551544261789116])
        self.assertTrue('comp_number_2digit_cat_DR' in dataframe.columns)

    def test_fit_function_four(self):
        ''' test for fit_function with 4 parameters '''
        dataframe, popt = research_utils.fit_function(dataframe=self.data, column='comp_number_2digit_cat', params=4, output_flag='liq_flg')
        self.assertEqual(list(popt), [-17.9612647867219, 164.1528862204603, 173872.78342787345, 173874.4677830207])
        self.assertTrue('comp_number_2digit_cat_DR' in dataframe.columns)

    def test_return_fit_two(self):
        ''' test for return_fit with 2 parameters '''
        fit_fco = research_utils.return_fit(dataframe=self.data, column='comp_number_2digit_cat', params=2, output_flag='liq_flg')
        self.assertEqual(fit_fco.tolist()[0:5], [6.367093555432245e-05, 0.666666656929304, 0.666666656929304, 0.666666656929304, 0.999999999493187])

    def test_return_fit_three(self):
        ''' test for return_fit with 3 parameters '''
        fit_fco = research_utils.return_fit(dataframe=self.data, column='comp_number_2digit_cat', params=3, output_flag='liq_flg')
        self.assertEqual(fit_fco.tolist()[0:5], [0.3429749227029198, 0.4276732142583224, 0.4276732142583224, 0.4276732142583224, 0.6090332584762393])

    def test_return_fit_four(self):
        ''' test for return_fit with 4 parameters '''
        fit_fco = research_utils.return_fit(dataframe=self.data, column='comp_number_2digit_cat', params=4, output_flag='liq_flg')
        self.assertEqual(fit_fco.tolist()[0:5], [5.623634898779768e-59, 3.552182760841771e-51, 3.552182760841771e-51, 3.552182760841771e-51, 1.417266990183783e-35])

    def test_inverse_and_transform_two(self):
        ''' test for inverse_and_transform with 2 parameters '''
        dataframe = research_utils.inverse_and_transform(dataframe=self.data, column='comp_number_2digit_cat', params=2, output_flag='liq_flg')
        self.assertEqual(dataframe.comp_number_2digit_cat_fit.tolist()[0:5], [1.043600595402121, 1.9999999955459995, 1.9999999955459995, 1.9999999955459995, 1.043600595402121])
        self.assertTrue('comp_number_2digit_cat_DR' and 'comp_number_2digit_cat' not in dataframe.columns)

    def test_inverse_and_transform_three(self):
        ''' test for inverse_and_transform with 3 parameters '''
        dataframe = research_utils.inverse_and_transform(dataframe=self.data, column='comp_number_2digit_cat', params=3, output_flag='liq_flg')
        self.assertEqual(dataframe.comp_number_2digit_cat_fit.tolist()[0:5], [-23.56898962468611, 4.6586068535973855, 4.6586068535973855, 4.6586068535973855, -23.56898962468611])
        self.assertTrue('comp_number_2digit_cat_DR' and 'comp_number_2digit_cat' not in dataframe.columns)

    def test_inverse_and_transform_four(self):
        ''' test for inverse_and_transform with 4 parameters '''
        dataframe = research_utils.inverse_and_transform(dataframe=self.data, column='comp_number_2digit_cat', params=4, output_flag='liq_flg')
        self.assertEqual(dataframe.comp_number_2digit_cat_fit.tolist()[0:5], [2.6180339603380443, 2.6180339603380443, 2.6180339603380443, 2.6180339603380443, 2.6180339603380443])
        self.assertTrue('comp_number_2digit_cat_DR' and 'comp_number_2digit_cat' not in dataframe.columns)

    def test_discretize_mdlp(self):
        ''' test for discretize_mdlp '''
        bin_edges = research_utils.discretize_mdlp(dataframe=self.data, column='discretize_feature', seed=7, output_flag='liq_flg', own_bins=[])
        self.assertEqual(bin_edges, [-inf, 4.5, inf])

    def test_discretize_quantile(self):
        ''' test for discretize_quantile '''
        bin_edges = research_utils.discretize_quantile(dataframe=self.data, column='discretize_feature', n=4, own_bins=[])
        self.assertEqual(bin_edges, [0.0, 1.75, 3.5, 5.25, 7.0])

    def test_discretize_numpy(self):
        ''' test for discretize_numpy '''
        bin_edges = research_utils.discretize_numpy(dataframe=self.data, column='discretize_feature', range_=None, weights=None, method='rice', own_bins=[])
        self.assertEqual(bin_edges, [0.0, 1.75, 3.5, 5.25, 7.0])

    def test_create_own_bins(self):
        ''' test for create_own_bins '''
        dataframe, column_own_bin_index_list = research_utils.create_own_bins(dataframe=self.data, column='replacement_feature', own_bins=[8, 'nan'])
        self.assertEqual(column_own_bin_index_list['replacement_feature'], [2.0, 3.0])
        self.assertEqual(dataframe.replacement_feature_disc.tolist()[-3:], [2.0, 1.0, 3.0])

    def test_discretize_column(self):
        ''' test for discretize_column '''
        column = 'replacement_feature'
        own_bins = [8, 'nan']
        filtered_data = self.data[self.data[column].isin(own_bins)]
        dataframe = self.data[~self.data[column].isin(own_bins)]
        dataframe, column_bin_edges, column_own_bin_index_list = research_utils.discretize_column(dataframe=dataframe,\
                column=column, output_flag='liq_flg', custom_bin_edges=[], own_bins=own_bins, how='quantile', seed=7, n=4, method='rice',\
                range_=None, weights=None, filtered_data=filtered_data, transform_flag=True)
        self.assertEqual(dataframe.replacement_feature_disc.tolist(), [0.0, 1.0, 2.0, 2.0, 3.0, 0.0, 4.0, 5.0])
        self.assertEqual(column_bin_edges[column], [-inf, 2.25, 3.5, 4.0, inf])
        self.assertEqual(column_own_bin_index_list[column], [4.0, 5.0])

    def test_scale_feature(self):
        """
            test for scale feature
            scaling default_feature [2, 3, 2, 3, 2, 3, 2, 3]
            mean: 2.5
            sigma: 0.5
            expecting default_feature_stand [-1.0, 1.0, ...]
        """
        column = "default_feature"
        result_data, scale_metrics = research_utils.scale_feature(dataframe=self.data, column=column)
        self.assertEqual(scale_metrics['default_feature'][0], 2.5)
        self.assertEqual(scale_metrics['default_feature'][1], 0.5)
        self.assertEqual(result_data['default_feature_stand'].tolist()[:2], [-1.0, 1.0])


    def test_transform_to_log_odds_standard_value(self):
        """
            test for transform to log odds with standard default rate
            log odds default_feature [2, 3, 2, 3, 2, 3, 2, 3]
            liq flg [1, 1, 1, 1, 1, 0, 0, 0]
            default rate [0.75, 0.5, 0.75, 0.5, 0.75 ... ]
            expected log odds mapping
            2: log(0.75/(1-0.75)) = 0.477121255
            3: log(0.5/(1-0.5)) = 0
        """
        column = "default_feature"
        result_data, log_odds_mapping = research_utils.transform_to_log_odds(dataframe=self.data, column=column, output_flag='liq_flg')
        self.assertEqual(log_odds_mapping['default_feature'], {(2, 1.0986122886681098), (3, 0.0)})
        self.assertEqual(result_data['default_feature_logOR'].tolist()[:2], [1.0986122886681098, 0])


    def test_transform_to_log_odds_edge_value(self):
        """
            test for transform to log odds where default rate = 0 or 1
            log odds discretize_feature [0, 1, 2, 3, 4, 5, 6, 7]
            liq flg [1, 1, 1, 1, 1, 0, 0, 0]
            default rate [1.0, 1.0, 1.0, 1.0, 1.0, 0.0, 0.0, 0.0]
            expected log odds mapping
            0, 1, 2, 3, 4: 27.63104323789236
            5, 6, 7: -27.63102111592755
        """
        column = "discretize_feature"
        result_data, _ = research_utils.transform_to_log_odds(dataframe=self.data, column=column, output_flag='liq_flg')
        self.assertEqual(result_data['discretize_feature_logOR'][0], 27.63104323789236)
        self.assertEqual(result_data['discretize_feature_logOR'][7], -27.63102111592755)


if __name__ == "__main__":
    unittest.main()
