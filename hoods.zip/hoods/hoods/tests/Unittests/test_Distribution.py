"""
Description: Test for Distribution.py script
"""
#############
# Libraries #
#############
import unittest
import warnings
from unittest.mock import MagicMock, patch
import pandas as pd
from Tools import Distribution
warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=FutureWarning)


########################################
# Class that contains unittest methods #
########################################
class testDistribution(unittest.TestCase):
    """ Class containing unittest methods """

    @patch('Tools.Distribution.import_module_variable')
    def setUp(self, mock):
        self.Distribution = Distribution.Distribution(data=None, company_size='test', output_flag='liq_flg',\
                for_prod_dir='tests/ForProd_test/PACKAGE_TEST/', logger=MagicMock())

    @patch('Tools.Distribution.score_and_order_data')
    def test_generate_calibrated_scores_no_threshold(self, mock):
        """ unittest for function generate_calibrated_scores """
        mock.return_value = pd.read_csv('tests/Unittests/data/calibration_sample.csv', index_col=None)
        self.Distribution.calibration_parameters = {'a': 1, 'b': 2, 'c': 3}
        self.Distribution.generate_calibrated_scores()
        self.assertEqual(self.Distribution.score_df['calibrated_proba'].tolist()[-4:], [1.670142184809518e-05, 0.0024726231566347743, 0.0024726231566347743, 0.04742587317756678])

    @patch('Tools.Distribution.score_and_order_data')
    def test_generate_calibrated_scores_threshold(self, mock):
        """ unittest for function generate_calibrated_scores """
        mock.return_value = pd.read_csv('tests/Unittests/data/calibration_sample.csv', index_col=None)
        self.Distribution.calibration_parameters = {'a': 1, 'b': 2, 'c': 3, 'd': 167, 'e': 5, 'threshold': -2}
        self.Distribution.generate_calibrated_scores()
        self.assertEqual(self.Distribution.score_df['calibrated_proba'].tolist()[-4:], [1.670142184809518e-05, 0.0024726231566347743, 0.0024726231566347743, 0.0075817882703349705])

    def test_add_1_to_25_hokoscale_to_scores(self):
        """ unittest for function add 1 to 25 hokoscale to scores """
        self.Distribution.score_df = pd.DataFrame({
            'calibrated_proba': [0.00005, 0.00035, 0.001, 0.1]})
        self.Distribution.add_1_to_25_hokoscale_to_scores()
        self.assertEqual(self.Distribution.score_df['bin125'].tolist(), [1, 4, 7, 21])
