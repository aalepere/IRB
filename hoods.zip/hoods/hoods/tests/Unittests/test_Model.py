''' Test for Model '''
import unittest
import warnings
from importlib import reload
from unittest.mock import MagicMock, patch
import pandas as pd
from Tools.Modelling import Model
warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=FutureWarning)

class testModel(unittest.TestCase):
    ''' tests for Model Class '''

    def setUp(self):
        train = pd.read_csv('tests/Unittests/data/train_model_sample.csv')
        test = pd.read_csv('tests/Unittests/data/test_model_sample.csv')
        self.Model = Model.Model(train_set=train, test_set=test, output_flag='liq_flg', logger=MagicMock(), for_prod_dir='tests/ForProd_test/PACKAGE_TEST/', company_size='test')

    def test_create_model_regular(self):
        ''' test for show coefficients in model '''
        self.Model.model_parameters['type'] = 'regular'
        self.Model.model_parameters['penalty'] = 'l2'
        self.Model.model_parameters['C'] = 1.0
        self.Model.create_model()
        self.assertEqual(self.Model.clf.coef_[0].tolist(), [-5.127811959073911e-07, 8.254442061571295e-12, -9.844022661136225e-08])

    @patch('builtins.print')
    def test_create_model_penalising(self, mock):
        ''' test for show coefficients in model '''
        self.Model.model_parameters['type'] = 'penalising'
        self.Model.model_parameters['iterations'] = 1000
        self.Model.model_parameters['penalty_dictionary'] = {}
        self.Model.create_model()
        self.assertEqual(self.Model.clf.coef_[0].tolist(), [-329.29800721541756, 7.2715981894908825, -59382.842778408085])


if __name__ == '__main__':
    unittest.main()
