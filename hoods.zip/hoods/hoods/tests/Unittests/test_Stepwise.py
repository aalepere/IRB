"""
Description: Test for Stepwise.py script
"""

import unittest
import os
import warnings
import pandas as pd
from unittest.mock import MagicMock, patch
from Tools import Stepwise, research_utils
warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=FutureWarning)


class testStepwise(unittest.TestCase):
    """ Class containing unittest methods """

    def setUp(self):
        self._data_test = pd.read_csv('tests/Unittests/data/stepwise_sample.csv', index_col=None)
        self.Stepwise = Stepwise.Stepwise(data=self._data_test, output_flag='liq_flg', logger=MagicMock(), package_flag=False)
        if not os.path.exists('data_sandbox'):
            os.makedirs('data_sandbox')

    def tearDown(self):
        os.rmdir('data_sandbox')

    def test_backwards_regression(self):
        """ unittest for function backwards regression """
        features_to_remove = self.Stepwise.backwards_regression()
        output_backwards = ''.join(open('data_sandbox/stepwise_back_model.txt').readlines())
        self.assertEqual(output_backwards[0:7], '\nCall:\n')
        self.assertEqual(features_to_remove, ['Unnamed: 0', 'liq_flg', 'company_id'])
        os.remove('data_sandbox/stepwise_back_model.txt')

if __name__ == "__main__":
    unittest.main()
