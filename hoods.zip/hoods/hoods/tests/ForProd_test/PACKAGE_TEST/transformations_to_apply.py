transformations_to_apply = {"comp_number_2digit_cat": {
        "discretize": {
            "apply": 0,
            "how": "",
            "method": "rice",
            "n": 4,
            "own_bins": [],
            "range": None,
            "seed": 7,
            "weights": None,
            "new_edges": []
        },
        "fit": {
            "apply": 0,
            "params": 2
        },
        "group": {
            "apply": 0,
            "cutoff": 9
        },
        "remove": {
            "apply": 0,
            "remove_val": 1
        },
        "replace_nans": {
            "rep_method": "median"
        },
        "winsorize": {
            "apply": 0,
            "threshold": 0.2
        }
    },
"replacement_feature": {
        "discretize": {
            "apply": 0,
            "how": "quantile",
            "method": "auto",
            "n": 3,
            "own_bins": [],
            "range": None,
            "seed": 7,
            "weights": None,
            "new_edges": []
        },
        "fit": {
            "apply": 0,
            "params": 2
        },
        "group": {
            "apply": 0,
            "cutoff": 4
        },
        "remove": {
            "apply": 0,
            "remove_val": 0
        },
        "replace_nans": {
            "rep_method": "median"
        },
        "winsorize": {
            "apply": 0,
            "threshold": 0.3
        }
    }
}
