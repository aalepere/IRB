model_parameters = {"type": "regular", "penalty": "l2", "C": 1.0}
