default_value_mapping = {"sic_1": "Undefined"}
