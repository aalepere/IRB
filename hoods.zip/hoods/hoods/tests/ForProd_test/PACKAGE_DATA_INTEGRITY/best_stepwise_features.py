best_stepwise_features = {'Best_Stepwise_features': ['company_id', 'liq_flg', 'feature3_disc_logOR_stand', 'feature1_cat_logOR_stand', 'feature2_cat_logOR_stand']}
