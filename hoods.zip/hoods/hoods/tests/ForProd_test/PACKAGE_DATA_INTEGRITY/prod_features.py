prod_features = {'prod_features': ['feature3_disc_logOR_stand', 'feature2_cat_logOR_stand']}
