default_value_mapping = {"feature1": "Undefined"}
