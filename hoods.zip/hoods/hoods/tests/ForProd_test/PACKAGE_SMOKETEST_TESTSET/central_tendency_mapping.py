central_tendency_mapping = {'feature3': 5555, 'feature5': 9890, 'feature1_cat': 10, 'feature2_cat': 1.5}
