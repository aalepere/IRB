transformations_to_apply = {"feature3" : {
        "discretize" : {
            "apply": 0, 
            "how": "",
            "method": "rice",
            "n": 4,
            "own_bins": [],
            "range": None,
            "seed": 7, 
            "weights": None, 
            "new_edges": []
            }, 
        "fit": {
            "apply": 0,
            "params": 2
        },
        "group": {
            "apply": 0,
            "cutoff": 9
        },
        "remove": {
            "apply": 0,
            "remove_val": 1
        },
        "replace_nans": {
            "rep_method": "median"
        },
        "winsorize": {
            "apply": 0,
            "threshold": 0.2
        }
    },
"feature4" : {
        "discretize" : {
            "apply": 1, 
            "how": "quantile",
            "method": "rice",
            "n": 3,
            "own_bins": ["nan", 0],
            "range": None,
            "seed": 7, 
            "weights": None, 
            "new_edges": []
            }, 
        "fit": {
            "apply": 0,
            "params": 2
        },
        "group": {
            "apply": 0,
            "cutoff": 9
        },
        "remove": {
            "apply": 0,
            "remove_val": 1
        },
        "replace_nans": {
            "rep_method": "median"
        },
        "winsorize": {
            "apply": 0,
            "threshold": 0.2
        }
    },
"feature5" : {
        "discretize" : {
            "apply": 0, 
            "how": "",
            "method": "rice",
            "n": 4,
            "own_bins": [],
            "range": None,
            "seed": 7, 
            "weights": None, 
            "new_edges": []
            }, 
        "fit": {
            "apply": 0,
            "params": 2
        },
        "group": {
            "apply": 0,
            "cutoff": 9
        },
        "remove": {
            "apply": 0,
            "remove_val": 1
        },
        "replace_nans": {
            "rep_method": "median"
        },
        "winsorize": {
            "apply": 0,
            "threshold": 0.2
        }
    },
"feature1_cat" : {
        "discretize" : {
            "apply": 0, 
            "how": "",
            "method": "rice",
            "n": 4,
            "own_bins": [],
            "range": None,
            "seed": 7, 
            "weights": None, 
            "new_edges": []
            }, 
        "fit": {
            "apply": 0,
            "params": 2
        },
        "group": {
            "apply": 0,
            "cutoff": 9
        },
        "remove": {
            "apply": 0,
            "remove_val": 1
        },
        "replace_nans": {
            "rep_method": "median"
        },
        "winsorize": {
            "apply": 0,
            "threshold": 0.2
        }
    },
"feature2_cat" : {
        "discretize" : {
            "apply": 0, 
            "how": "",
            "method": "rice",
            "n": 4,
            "own_bins": [],
            "range": None,
            "seed": 7, 
            "weights": None, 
            "new_edges": []
            }, 
        "fit": {
            "apply": 0,
            "params": 2
        },
        "group": {
            "apply": 0,
            "cutoff": 9
        },
        "remove": {
            "apply": 0,
            "remove_val": 1
        },
        "replace_nans": {
            "rep_method": "median"
        },
        "winsorize": {
            "apply": 0,
            "threshold": 0.2
        }
    }
}



