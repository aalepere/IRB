disc_log_dr_value_mapping = {'feature4': {(0, 0), (1, -0.33), (2, -0.69), (3, -9.21), (4, 7.8), (5, 12)}}
