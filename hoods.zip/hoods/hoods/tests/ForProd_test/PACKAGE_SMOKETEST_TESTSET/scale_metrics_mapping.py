scale_metrics_mapping = {'feature1_cat_logOR': [0, 1], 'feature2_cat_logOR': [0, 1], 'feature3_logOR': [0, 1], 'feature3_logOR':[1,1],'feature4_disc_logOR':[1,1], 'feature5_logOR':[1,1]}
