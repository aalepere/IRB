disc_bin_edges_mapping = {'feature4': [10, 4000, 7000, 99000]}
