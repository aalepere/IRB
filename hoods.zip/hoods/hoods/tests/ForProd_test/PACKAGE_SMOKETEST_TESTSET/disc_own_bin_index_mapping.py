disc_own_bin_index_mapping = {'feature4': [3.0, 4.0]}
