cat_to_num_mapping = {"feature2": {"feature2_cat": {"Evans Mockler Limited": 1, "Michel": 2}},
 "feature1": {"feature1_cat" : {"Undefined" : 2, "industry": 1}}}
