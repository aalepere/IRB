''' Tests for HOODS transformations on the test set '''
import unittest
import subprocess
import sys
import os
try:
    BRANCH_NAME = os.environ['BRANCH_NAME']
except Exception:
    sys.exit('\n\nNEED TO PUT BRANCH NAME in environment using export BRANCH_NAME=feature/name_of_branch in bash OR setting BRANCH_NAME variable in tox.ini\nMAKE SURE YOU HAVE !! COMMITED AND PUSHED !! ALL YOUR CHANGES TO THE BRANCH OR THEY WILL NOT BE IN THE PACKAGE\n\n')

def replace(file_path, pattern, subst):
    with open('tmp_requirements.txt', 'w') as new:
        with open(file_path) as f:
            for line in f.readlines():
                line = line.replace('\n','')
                if line == pattern:
                    new.write('{}\n'.format(subst))
                else:
                    new.write('{}\n'.format(line))
    os.rename('tmp_requirements.txt', 'requirements.txt')


class testTuinTox(unittest.TestCase):
    ''' test for HOODS transformations on the test set '''

    def setUp(self):
        subprocess.run(['git', 'clone', 'git@gitlab.com:hokodo/data-science/had.git'], stdout=subprocess.PIPE)

    def tearDown(self):
        _ = subprocess.run(['rm', '-rf', 'had'])

    def test_run_tuin_tox(self):
        os.chdir('had/django_had/')
        replace('requirements.txt', 'git+ssh://git@gitlab.com/hokodo/data-science/hoods#egg=hoods', 'git+ssh://git@gitlab.com/hokodo/data-science/hoods@{}#egg=hoods'.format(BRANCH_NAME))
        worked = subprocess.run(['tox'])
        self.assertEqual(worked.returncode, 0)
        os.chdir('../../')

if __name__ == '__main__': 
    unittest.main()
