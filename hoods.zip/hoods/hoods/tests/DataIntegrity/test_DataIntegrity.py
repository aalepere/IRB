''' Tests for HOODS data integrity '''
import os
import pandas as pd
import unittest
from sklearn import model_selection
from unittest.mock import MagicMock
import glob
from Tools.Modelling import transform_utils, FeatureTransTest, DataPrepTest, Model
from Tools import DataInitTrain, DataPrepTrain, FeatureTransTrain, GiniAnalysis, Stepwise, PreModelAnalysis

class testDataIntegrity(unittest.TestCase):
    ''' test for HOODS data integrity '''

    def setUp(self):
        if not os.path.exists('data_sandbox'):
            os.mkdir('data_sandbox')
        self.data_path = 'tests/DataIntegrity/data/DataIntegrity_Input.csv'
        self._data = pd.read_csv(self.data_path)
        self.train_size = 0.8
        self.company_size = 'PACKAGE_DATA_INTEGRITY'
        self.for_prod_dir = 'tests/ForProd_test/PACKAGE_DATA_INTEGRITY/'
        self.files_to_keep = set(glob.glob('{}*.py'.format(self.for_prod_dir)))
        self.output_flag = 'liq_flg'
    
    def tearDown(self):
        files_to_delete = set(glob.glob('data_sandbox/*') + glob.glob('{}*.py'.format(self.for_prod_dir)))
        for file_path in (files_to_delete - self.files_to_keep):
            os.remove(file_path)
        os.remove('2_features_to_remove.csv')
        os.rmdir('data_sandbox')
    
    def test_DataIntegrity(self):

        ### Test Data Integrity in Data Init and Data Prep for train set ###
        self._data = self._data[(self._data.company_status_at_observation == 'Active') & (self._data['size'] == self.company_size)]
        self._data.drop(columns=['size', 'company_status_at_observation'], inplace=True)
        self._train_set, self._test_set = model_selection.train_test_split(self._data, train_size=self.train_size, random_state=7)
        self._test_set.to_csv('data_sandbox/1_DataInitTestSet.csv', index=False, header=True)
        try:
            self.assertEqual(self._train_set.shape, (90, 6))
            self.assertEqual(self._test_set.shape, (23, 6))
            self.assertEqual(self._train_set.feature3.sum(), 7025989391)
            self.assertEqual(self._test_set.feature3.sum(), 3003728705)
        except:
            print("\n \n \n DataInitTrain FAILED \n \n \n ")
            raise 

        self.dataPrepTrain = DataPrepTrain.DataPrepTrain(data=self._train_set, output_flag='liq_flg', missing_threshold=0.8, for_prod_dir=self.for_prod_dir, datasets_dir='tests/SmokeTest/data/', logger=MagicMock())
        self.dataPrepTrain.prepare_train_data()
        try:
            self.assertEqual(self.dataPrepTrain._data.shape, (90, 6))
            self.assertEqual(self.dataPrepTrain._data.feature3.sum(), 7025989391)
        except: 
            print("\n \n \n DataPrepTrain FAILED. \n \n \n")
            raise

        ### Test Data Integrity in Gini Analysis ###
        self.giniAnal = GiniAnalysis.GiniAnalysis(data=self.dataPrepTrain._data, output_flag='liq_flg', logger=MagicMock())
        self.giniAnal.retrieve_gini_analysis()
        self.features_to_remove = pd.read_csv('2_features_to_remove.csv')
        self.features_to_remove['feature2_cat'] = True
        self.features_to_remove.to_csv('2_features_to_remove.csv', index=None)
        self.giniAnal.write_filtered_dataframe()
        try: 
            self.assertEqual(self.giniAnal._data.shape, (90, 6))
            self.assertEqual(self.giniAnal._data.feature3.sum(), 7025989391)
        except:
            print("\n \n \n GiniAnalysis FAILED \n \n \n")
            raise

        ### Test Data Integrity in Feature Trans for train set ###
        self.featTransTrain = FeatureTransTrain.FeatureTransTrain(data=self.giniAnal._data, output_flag='liq_flg', for_prod_dir=self.for_prod_dir, logger=MagicMock(), cores=1)
        self.featTransTrain.transform_scale_train_set()
        try: 
            self.assertEqual(self.featTransTrain._data.shape, (80, 5))
        except:
            print("\n \n \n FeatTransTrain FAILED \n \n \n")
            raise

        ### Test Data Integrity in Stepwise for train set ###
        self.stepwise = Stepwise.Stepwise(data=self.featTransTrain._data, output_flag='liq_flg', logger=MagicMock(), package_flag=False)
        self.stepwise.backwards_regression()
        try:
            self.assertEqual(self.stepwise._data.shape, (80, 5))
        except: 
            print("\n \n \n Stepwise FAILED \n \n \n")
            raise

        ### Test Data Integrity in Tranform Test for test set ###
        self.data_path = 'data_sandbox/1_DataInitTestSet.csv'
        df = pd.read_csv(self.data_path, index_col=0)
        df.reset_index(drop=True, inplace=True)
        """
        self.dataInitTest = DataInitTest.DataInitTest(data_path=self.data_path, for_prod_dir=self.for_prod_dir, logger=MagicMock())
        self.dataInitTest.initiate_test_data()
        try:
            self.assertEqual(self.dataInitTest._test_set.shape, (23, 5))
            self.assertEqual(self.dataInitTest._test_set.feature3.sum(), 3003728705.0)
        except:
            print("\n \n \n DataInitTest FAILED \n \n \n")
            raise
        """

        self.dataPrepTest = DataPrepTest.DataPrepTest(data=df, for_prod_dir=self.for_prod_dir, output_flag='liq_flg', logger=MagicMock())
        self.dataPrepTest.prepare_test_data()
        try:
            self.assertEqual(self.dataPrepTest._data.shape, (23, 5))
            self.assertEqual(self.dataPrepTest._data.feature3.sum(), 3003728705.0)
        except:
            print("\n \n \n DataPrepTest FAILED \n \n \n")
            raise
        
        file_name_list = ['scale_metrics_mapping', 'central_tendency_mapping', 'disc_bin_edges_mapping', 'disc_own_bin_index_mapping', 'log_odds_mapping']
        self.scale_metrics_mapping, self.central_tendency_mapping, self.disc_bin_edges_mapping, self.disc_own_bin_index_mapping, self.log_odds_mapping = transform_utils.load_mapping_files(file_name_list, self.for_prod_dir)
        self.featTransTest = FeatureTransTest.FeatureTransTest(data=self.dataPrepTest._data, for_prod_dir=self.for_prod_dir, output_flag='liq_flg', logger=MagicMock(), scale_metrics_mapping=self.scale_metrics_mapping, disc_bin_edges_mapping=self.disc_bin_edges_mapping, central_tendency_mapping=self.central_tendency_mapping, disc_own_bin_index_mapping=self.disc_own_bin_index_mapping, log_odds_mapping=self.log_odds_mapping, cores=1)
        self.featTransTest.transform_scale_test_set()
        try:
            self.assertEqual(self.featTransTest._data.shape, (23, 5))
            self.assertEqual(self.featTransTest._data.feature3_disc_logOR_stand.sum(), -0.9490081161206995)
        except:
            print("\n \n \n FeatTransTest FAILED \n \n \n")
            raise

        ### Test Data Integrity in PreModelAnalysis ###
        self.data_path_train = 'data_sandbox/5_FeatTrans.csv'
        self.preModelTrain = PreModelAnalysis.PreModelAnalysis(data_path=self.data_path_train, data_path_out='data_sandbox/8_Train_data.csv', logger=MagicMock(), output_flag=self.output_flag, for_prod_dir=self.for_prod_dir)
        self.preModelTrain.remove_features_and_write_data()
        try:
            self.assertEqual(self.preModelTrain._data.shape, (80, 4))
            self.assertEqual(self.preModelTrain._data.feature3_disc_logOR_stand.max(), 0.5642298500365145)
            self.assertEqual(self.preModelTrain._data.feature3_disc_logOR_stand.min(), -2.267989650225132)
        except:
            print("\n \n \n PreModelTrain FAILED \n \n \n")
            raise

        self.data_path_test = 'data_sandbox/7_TransformTest.csv'
        self.preModelTest = PreModelAnalysis.PreModelAnalysis(data_path=self.data_path_test, data_path_out='data_sandbox/8_Test_data.csv', logger=MagicMock(), output_flag=self.output_flag, for_prod_dir=self.for_prod_dir)
        self.preModelTest.remove_features_and_write_data()
        try:
            self.assertEqual(self.preModelTest._data.shape, (23, 4))
            self.assertEqual(self.preModelTest._data.feature3_disc_logOR_stand.sum(), -0.9490081161206999)
        except:
            print("\n \n \n PreModelTest FAILED \n \n \n")
            raise

        ### Test Data Integrity in Model ###
        self._train_set = pd.read_csv('data_sandbox/8_Train_data.csv')
        self._test_set = pd.read_csv('data_sandbox/8_Test_data.csv')
        self.Model = Model.Model(train_set=self._train_set, test_set=self._test_set, for_prod_dir=self.for_prod_dir, output_flag='liq_flg', logger=MagicMock(), company_size='test')
        self.Model.create_model()
        try:
            self.assertEqual(self.Model._X_train.shape, (80, 2))
            self.assertEqual(self.Model._X_test.shape, (23, 2))
            self.assertEqual(self.Model._X_train.feature3_disc_logOR_stand.max(), 0.5642298500365145)
            self.assertEqual(self.Model._X_train.feature3_disc_logOR_stand.min(), -2.267989650225132)
            self.assertEqual(self.Model._X_test.feature3_disc_logOR_stand.sum(), -0.9490081161206999)
            self.assertEqual(self.Model.clf.coef_[0].tolist(), [0.8431111862689038, 0.3267250597944672])
        except:
            print("\n \n \n Model FAILED \n \n \n")
            raise

if __name__ == '__main__':
    unittest.main()
