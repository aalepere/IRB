''' Tests for HOODS transformations on the test set '''
import unittest
from unittest.mock import MagicMock, patch
import pandas as pd
from Tools.Modelling import transform_utils, FeatureTransTest, DataPrepTest

class testTransformation(unittest.TestCase):
    ''' test for HOODS transformations on the test set '''

    def setUp(self):
        self.for_prod_dir = 'tests/ForProd_test/PACKAGE_SMOKETEST_TESTSET/'
        self.data = pd.read_csv('tests/SmokeTest/data/SmokeTest_Input.csv')
        file_name_list = ['scale_metrics_mapping', 'central_tendency_mapping', 'disc_bin_edges_mapping', 'disc_own_bin_index_mapping', 'log_odds_mapping']
        self.scale_metrics_mapping, self.central_tendency_mapping, self.disc_bin_edges_mapping, self.disc_own_bin_index_mapping, self.log_odds_mapping =\
                transform_utils.load_mapping_files(file_name_list, directory=self.for_prod_dir)
        self.SmokeTest_Output = pd.read_csv('tests/SmokeTest/data/SmokeTest_Output.csv', index_col=None)

    @patch('Tools.Modelling.FeatureTransTest.pd.DataFrame.to_csv')
    def test_transformation(self, mock):
        ''' test for all the possible transformations in HOODS '''
        self.dataPrepTest = DataPrepTest.DataPrepTest(data=self.data, for_prod_dir=self.for_prod_dir, output_flag='liq_flg', logger=MagicMock())
        self.dataPrepTest.prepare_test_data()
        self.featTransTest = FeatureTransTest.FeatureTransTest(data=self.dataPrepTest._data, for_prod_dir=self.for_prod_dir, prod=False,\
                output_flag='liq_flg', cores=1, logger=MagicMock(), scale_metrics_mapping=self.scale_metrics_mapping,\
                disc_bin_edges_mapping=self.disc_bin_edges_mapping, central_tendency_mapping=self.central_tendency_mapping,\
                disc_own_bin_index_mapping=self.disc_own_bin_index_mapping, log_odds_mapping=self.log_odds_mapping)
        self.featTransTest.transform_scale_test_set()
        pd.util.testing.assert_frame_equal(self.featTransTest._data, self.SmokeTest_Output)

if __name__ == '__main__':
    unittest.main()
