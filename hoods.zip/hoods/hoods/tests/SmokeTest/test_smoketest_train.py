''' Tests for HOODS transformations on the train set '''
import unittest
import importlib
from unittest.mock import MagicMock, patch
import glob
import pandas as pd
from Tools import DataPrepTrain, FeatureTransTrain

class testTransformation(unittest.TestCase):
    ''' test for HOODS transformations on the test set '''

    def setUp(self):
        self.for_prod_dir = 'tests/SmokeTest/data/'
        self._train_set = pd.read_csv('tests/SmokeTest/data/SmokeTest_Train_Input.csv')
        self.SmokeTest_Train_Output = pd.read_csv('tests/SmokeTest/data/SmokeTest_Train_Output.csv', index_col=None)

    def tearDown(self):
        pass

    @patch('Tools.FeatureTransTrain.pd.DataFrame.to_csv', mock1=MagicMock())
    @patch('Tools.FeatureTransTrain.FeatureTransTrain.write_scale_mappings', mock2=MagicMock())
    def test_transformation(self, mock1, mock2):
        ''' test for all the possible transformations in HOODS '''
        self.dataPrepTrain = DataPrepTrain.DataPrepTrain(data=self._train_set, output_flag='liq_flg', logger=MagicMock(), datasets_dir='tests/SmokeTest/data/',\
                missing_threshold=0.7, for_prod_dir=self.for_prod_dir)
        with patch('Tools.DataPrepTrain.write_to_python_file'):
            self.dataPrepTrain.prepare_train_data()
        self.featTransTrain = FeatureTransTrain.FeatureTransTrain(data=self.dataPrepTrain._data, for_prod_dir=self.for_prod_dir, output_flag='liq_flg', cores=1, logger=MagicMock())
        with patch('Tools.FeatureTransTrain.FeatureTransTrain.merge_and_write_dictionaries'):
            self.featTransTrain.transform_scale_train_set()
        pd.util.testing.assert_frame_equal(self.featTransTrain._data, self.SmokeTest_Train_Output)

if __name__ == '__main__':
    unittest.main()
