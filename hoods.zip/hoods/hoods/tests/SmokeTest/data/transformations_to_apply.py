transformations_to_apply = {"feature1_cat" : {
        "discretize" : {
            "apply": 0, 
            "how": "",
            "method": "rice",
            "n": 4,
            "own_bins": [],
            "range": None,
            "seed": 7, 
            "weights": None, 
            "new_edges": []
            }, 
        "fit": {
            "apply": 0,
            "params": 2
        },
        "group": {
            "apply": 0,
            "cutoff": 9
        },
        "remove": {
            "apply": 0,
            "remove_val": 1
        },
        "replace_nans": {
            "rep_method": "median"
        },
        "winsorize": {
            "apply": 0,
            "threshold": 0.2
        }
    },
"feature2_cat" : {
        "discretize" : {
            "apply": 0, 
            "how": "quantile",
            "method": "rice",
            "n": 3,
            "own_bins": [],
            "range": None,
            "seed": 7, 
            "weights": None, 
            "new_edges": []
            }, 
        "fit": {
            "apply": 0,
            "params": 2
        },
        "group": {
            "apply": 0,
            "cutoff": 9
        },
        "remove": {
            "apply": 0,
            "remove_val": 1
        },
        "replace_nans": {
            "rep_method": "median"
        },
        "winsorize": {
            "apply": 0,
            "threshold": 0.2
        }
    },
"feature3" : {
        "discretize" : {
            "apply": 0, 
            "how": "",
            "method": "rice",
            "n": 4,
            "own_bins": [],
            "range": None,
            "seed": 7, 
            "weights": None, 
            "new_edges": []
            }, 
        "fit": {
            "apply": 0,
            "params": 2
        },
        "group": {
            "apply": 0,
            "cutoff": 9
        },
        "remove": {
            "apply": 0,
            "remove_val": 107
        },
        "replace_nans": {
            "rep_method": "median"
        },
        "winsorize": {
            "apply": 0,
            "threshold": 0.2
        }
    },
"feature4" : {
        "discretize" : {
            "apply": 0, 
            "how": "",
            "method": "rice",
            "n": 4,
            "own_bins": [],
            "range": None,
            "seed": 7, 
            "weights": None, 
            "new_edges": []
            }, 
        "fit": {
            "apply": 0,
            "params": 2
        },
        "group": {
            "apply": 1,
            "cutoff": 5000
        },
        "remove": {
            "apply": 0,
            "remove_val": 1
        },
        "replace_nans": {
            "rep_method": "median"
        },
        "winsorize": {
            "apply": 0,
            "threshold": 0.2
        }
    },
"feature5" : {
        "discretize" : {
            "apply": 0, 
            "how": "",
            "method": "rice",
            "n": 4,
            "own_bins": [],
            "range": None,
            "seed": 7, 
            "weights": None, 
            "new_edges": []
            }, 
        "fit": {
            "apply": 0,
            "params": 2
        },
        "group": {
            "apply": 0,
            "cutoff": 9
        },
        "remove": {
            "apply": 0,
            "remove_val": 1
        },
        "replace_nans": {
            "rep_method": "median"
        },
        "winsorize": {
            "apply": 1,
            "threshold": 0.1
        }
    },
"feature6" : {
        "discretize" : {
            "apply": 1, 
            "how": "quantile",
            "method": "rice",
            "n": 3,
            "own_bins": ["nan", 0],
            "range": None,
            "seed": 7, 
            "weights": None, 
            "new_edges": []
            }, 
        "fit": {
            "apply": 0,
            "params": 2
        },
        "group": {
            "apply": 0,
            "cutoff": 9
        },
        "remove": {
            "apply": 0,
            "remove_val": 1
        },
        "replace_nans": {
            "rep_method": "median"
        },
        "winsorize": {
            "apply": 0,
            "threshold": 0.1
        }
    },
"feature7" : {
        "discretize" : {
            "apply": 0, 
            "how": "",
            "method": "rice",
            "n": 4,
            "own_bins": [],
            "range": None,
            "seed": 7, 
            "weights": None, 
            "new_edges": []
            }, 
        "fit": {
            "apply": 0,
            "params": 2
        },
        "group": {
            "apply": 0,
            "cutoff": 9
        },
        "remove": {
            "apply": 0,
            "remove_val": 1
        },
        "replace_nans": {
            "rep_method": "median"
        },
        "winsorize": {
            "apply": 0,
            "threshold": 0.1
        }
    },
"feature8" : {
        "discretize" : {
            "apply": 0, 
            "how": "",
            "method": "rice",
            "n": 4,
            "own_bins": [],
            "range": None,
            "seed": 7, 
            "weights": None, 
            "new_edges": []
            }, 
        "fit": {
            "apply": 0,
            "params": 2
        },
        "group": {
            "apply": 0,
            "cutoff": 9
        },
        "remove": {
            "apply": 0,
            "remove_val": 1
        },
        "replace_nans": {
            "rep_method": "mean"
        },
        "winsorize": {
            "apply": 0,
            "threshold": 0.1
        }
    },
"feature9" : {
        "discretize" : {
            "apply": 0, 
            "how": "",
            "method": "rice",
            "n": 4,
            "own_bins": [],
            "range": None,
            "seed": 7, 
            "weights": None, 
            "new_edges": []
            }, 
        "fit": {
            "apply": 0,
            "params": 2
        },
        "group": {
            "apply": 0,
            "cutoff": 9
        },
        "remove": {
            "apply": 0,
            "remove_val": 1
        },
        "replace_nans": {
            "rep_method": "median"
        },
        "winsorize": {
            "apply": 0,
            "threshold": 0.1
        }
    },
"feature10" : {
        "discretize" : {
            "apply": 0, 
            "how": "",
            "method": "rice",
            "n": 4,
            "own_bins": [],
            "range": None,
            "seed": 7, 
            "weights": None, 
            "new_edges": []
            }, 
        "fit": {
            "apply": 0,
            "params": 2
        },
        "group": {
            "apply": 0,
            "cutoff": 9
        },
        "remove": {
            "apply": 0,
            "remove_val": 1
        },
        "replace_nans": {
            "rep_method": "mode"
        },
        "winsorize": {
            "apply": 0,
            "threshold": 0.1
        }
    },
"feature11" : {
        "discretize" : {
            "apply": 0, 
            "how": "",
            "method": "rice",
            "n": 4,
            "own_bins": [],
            "range": None,
            "seed": 7, 
            "weights": None, 
            "new_edges": []
            }, 
        "fit": {
            "apply": 1,
            "params": 2
        },
        "group": {
            "apply": 0,
            "cutoff": 9
        },
        "remove": {
            "apply": 0,
            "remove_val": 1
        },
        "replace_nans": {
            "rep_method": "median"
        },
        "winsorize": {
            "apply": 0,
            "threshold": 0.1
        }
    },
"feature12" : {
        "discretize" : {
            "apply": 0, 
            "how": "",
            "method": "rice",
            "n": 4,
            "own_bins": [],
            "range": None,
            "seed": 7, 
            "weights": None, 
            "new_edges": []
            }, 
        "fit": {
            "apply": 1,
            "params": 3
        },
        "group": {
            "apply": 0,
            "cutoff": 9
        },
        "remove": {
            "apply": 0,
            "remove_val": 1
        },
        "replace_nans": {
            "rep_method": "median"
        },
        "winsorize": {
            "apply": 0,
            "threshold": 0.1
        }
    },
"feature13" : {
        "discretize" : {
            "apply": 0, 
            "how": "",
            "method": "rice",
            "n": 4,
            "own_bins": [],
            "range": None,
            "seed": 7, 
            "weights": None, 
            "new_edges": []
            }, 
        "fit": {
            "apply": 1,
            "params": 4
        },
        "group": {
            "apply": 0,
            "cutoff": 9
        },
        "remove": {
            "apply": 0,
            "remove_val": 1
        },
        "replace_nans": {
            "rep_method": "median"
        },
        "winsorize": {
            "apply": 0,
            "threshold": 0.1
        }
    }
}



