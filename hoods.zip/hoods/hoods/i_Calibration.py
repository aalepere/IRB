"""
HOODS Step 9 : Calibrate the Model
"""

####################################
# Libraries and Runtime Parameters #
####################################
import warnings
import pandas as pd
from . import hoods_settings
from .Tools import Timer, research_utils, Calibration
warnings.filterwarnings("ignore", category=DeprecationWarning)
warnings.filterwarnings("ignore", category=FutureWarning)
company_size, output_flag, for_prod_dir = hoods_settings.get_runtime_params()

############
# Analysis #
############
logger = research_utils.get_logger(company_size)
timer = Timer.Timer(logger=logger)

def run(bin_number, performance_window, anchor_point, add_constraint):
    ''' run model '''
    timer.initiate_timer('Running calibration')
    train_set = pd.read_csv(hoods_settings.INITIATE_MODEL_TRAIN_SET)
    calibration = Calibration.Calibration(data=train_set, bin_number=bin_number, performance_window=performance_window,\
					  anchor_point=anchor_point, company_size=company_size, output_flag=output_flag,\
					  logger=logger, for_prod_dir=for_prod_dir, add_constraint=add_constraint)
    calibration.run_calibration()
    timer.finish_timer('Running calibration', 'Run calibration for train set')
